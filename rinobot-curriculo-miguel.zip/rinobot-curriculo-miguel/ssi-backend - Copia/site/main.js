// Firebase SDKs 
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  signInWithEmailAndPassword,
  onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import {
  getFirestore,
  doc,
  setDoc
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

// Configuração do Firebase
const firebaseConfig = {
  apiKey: "AIzaSyDSbjtPpor8so-CgM4JIfZGbbzRbywxX9c",
  authDomain: "ss-investmentgg.firebaseapp.com",
  projectId: "ss-investmentgg",
  storageBucket: "ss-investmentgg.appspot.com",
  messagingSenderId: "442430960916",
  appId: "1:442430960916:web:ca2600464560d8eed67e01",
  measurementId: "G-SVDLWWDXWD"
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// DOM
const popup = document.getElementById("loginPopup");
const googleBtn = document.getElementById("googleLoginBtn");
const emailForm = document.getElementById("email-login-form");
const greeting = document.getElementById("userGreeting");
const resultBox = document.getElementById("resultado");
const userPhoto = document.getElementById("userPhoto");
const closePopup = document.getElementById("closePopup");
const startButton = document.getElementById("startButton");
const logoutBtn = document.getElementById("logoutBtn");
const discordBtn = document.getElementById("discordLoginBtn");
const loginButtons = document.getElementById("loginButtons");
const userArea = document.getElementById("userArea");

// Mostrar popup ao clicar em "Iniciar"
startButton.addEventListener("click", () => {
  popup.classList.remove("hidden");
});

// Fechar popup
closePopup.addEventListener("click", () => {
  popup.classList.add("hidden");
});

// Salvar usuário no Firestore
async function salvarUsuario(user) {
  const userRef = doc(db, "usuarios", user.uid);
  await setDoc(userRef, {
    nome: user.displayName || user.email,
    email: user.email,
    uid: user.uid,
    foto: user.photoURL || "assets/images/7915522.png",
    criadoEm: new Date()
  });
  console.log("Usuário salvo no Firestore.");
}

// Aplica dados do usuário (Firebase/Discord)
async function aposLogin(user) {
  const nome = user.displayName || user.username || user.email;
  const foto = user.photoURL || user.avatarURL || "assets/images/7915522.png";

  greeting.innerText = `Olá, ${nome}!`;
  userPhoto.src = foto;
  userPhoto.alt = nome;

  resultBox.innerText = "Login realizado com sucesso!";
  userArea.style.display = "flex";
  loginButtons.style.display = "none";
  popup.classList.add("hidden");

  carregarDadosDoJogador();
}

// Google Login
googleBtn.addEventListener("click", async () => {
  const provider = new GoogleAuthProvider();
  try {
    const result = await signInWithPopup(auth, provider);
    const user = result.user;
    await salvarUsuario(user);
    aposLogin(user);
    console.log("Login com Google bem-sucedido:", user);
  } catch (error) {
    console.error("Erro no login com Google:", error);
    resultBox.innerText = "Erro: " + error.message;
  }
});

// Email/Senha Login
emailForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;

  try {
    const result = await signInWithEmailAndPassword(auth, email, password);
    const user = result.user;
    await salvarUsuario(user);
    aposLogin(user);
    console.log("Login com email/senha bem-sucedido:", user);
  } catch (error) {
    console.error("Erro no login com email:", error);
    resultBox.innerText = "Erro: " + error.message;
  }
});

// Sessão automática (Firebase)
onAuthStateChanged(auth, (user) => {
  if (user) {
    aposLogin(user);
    console.log("Sessão restaurada automaticamente:", user);
  }
});

// Login via Discord (query ?user=...)
const urlParams = new URLSearchParams(window.location.search);
const discordData = urlParams.get("user");

if (discordData) {
  try {
    const user = JSON.parse(decodeURIComponent(discordData));
    const avatarURL = `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`;

    // Adiciona propriedades para usar no aposLogin()
    user.displayName = `${user.username}#${user.discriminator}`;
    user.avatarURL = avatarURL;

    // Salva o ID do Discord no localStorage
    localStorage.setItem("discord_id", user.id);

    aposLogin(user);
    localStorage.setItem("discord_user", JSON.stringify(user));

    // Limpa query string da URL
    history.replaceState({}, document.title, "/site/");
    console.log("Login via Discord detectado:", user);
  } catch (error) {
    console.error("Erro ao processar dados do Discord:", error);
  }
} else {
  // Caso já tenha salvo localmente (volta à página depois)
  const storedDiscordUser = localStorage.getItem("discord_user");
  if (storedDiscordUser) {
    const user = JSON.parse(storedDiscordUser);
    user.avatarURL = `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`;
    user.displayName = `${user.username}#${user.discriminator}`;
    aposLogin(user);
  }
}

// Logout
logoutBtn.addEventListener("click", () => {
  auth.signOut().catch(err => console.error("Erro no logout Firebase:", err));
  localStorage.clear();

  greeting.innerText = "";
  resultBox.innerText = "Logout feito com sucesso!";
  userPhoto.src = "assets/images/7915522.png";
  userPhoto.alt = "Avatar padrão";
  popup.classList.remove("hidden");
  userArea.style.display = "none";
  loginButtons.style.display = "flex";

  console.log("Usuário deslogado.");
});

// Botão de login via Discord
discordBtn.addEventListener("click", () => {
  window.location.href = "http://localhost:3000/auth/discord";
});

async function carregarDadosDoJogador() {
  const discordId = localStorage.getItem("discord_id"); // Obtém o ID do Discord do localStorage
  const response = await fetch(`/api/player/${discordId}`);

  if (!discordId) {
    document.getElementById("perfil").innerHTML = `
      <p>❌ Usuário não autenticado! Faça login para ver seus dados.</p>
    `;
    return;
  }

  try {
    const data = await response.json();

    if (response.ok) {
      // Exibir os dados do jogador no HTML
      document.getElementById("perfil").innerHTML = `
        <h2>Perfil do Jogador</h2>
        <p><strong>Nome:</strong> ${data.nome}</p>
        <p><strong>Saldo:</strong> $${data.saldo.toFixed(2)}</p>
        <p><strong>Nível:</strong> ${data.level}</p>
        <p><strong>EXP:</strong> ${data.exp}</p>
        <p><strong>Conformidade:</strong> ${data.conformidade}</p>
        <p><strong>Moradia:</strong> ${data.moradia}</p>
      `;
    } else {
      // Jogador não encontrado
      document.getElementById("perfil").innerHTML = `
        <p>${data.erro}</p>
      `;
    }
  } catch (error) {
    console.error("Erro ao buscar dados do jogador:", error);
    document.getElementById("perfil").innerHTML = `
      <p>❌ Erro ao carregar os dados do jogador.</p>
    `;
  }
}

// Chamar a função ao carregar a página
window.onload = carregarDadosDoJogador;

const fs = require('fs');
const express = require('express');
const apiApp = express();

apiApp.get('/getPlayerData/:discordId', (req, res) => {
  const discordId = req.params.discordId;

  console.log("ID do Discord usado na requisição:", discordId);

  fs.readFile('players.json', 'utf8', (err, data) => {
    if (err) {
      return res.status(500).json({ error: 'Erro ao ler o banco de dados.' });
    }

    const players = JSON.parse(data);
    const player = players[discordId];

    if (!player) {
      return res.status(404).json({ error: 'Jogador não encontrado.' });
    }

    return res.json(player);
  });
});
