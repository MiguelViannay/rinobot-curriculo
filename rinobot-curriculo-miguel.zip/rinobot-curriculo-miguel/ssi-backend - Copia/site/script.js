async function carregarDados() {
  const resultado = document.getElementById("resultado");
  const userId = localStorage.getItem("userId");
  const discordUserRaw = localStorage.getItem("discordUser");

  let userIdentifier;

  if (userId) {
    userIdentifier = userId;
  } else if (discordUserRaw) {
    const discordUser = JSON.parse(discordUserRaw);
    userIdentifier = discordUser.id;
  }

  if (!userIdentifier) {
    resultado.innerText = "❌ Usuário não autenticado!";
    return;
  }

  try {
    const resposta = await fetch(`/api/player/${userIdentifier}`);
    const dados = await resposta.json();

    if (!resposta.ok || !dados.nome) {
      resultado.innerText = "⚠️ Jogador não encontrado!";
      return;
    }

    resultado.innerText = `👤 Nome: ${dados.nome}\n💰 Saldo: ${dados.saldo} coins`;
  } catch (error) {
    resultado.innerText = "❌ Erro ao carregar os dados.";
    console.error("Erro na requisição:", error);
  }
}

async function carregarDadosDoJogador(discordId) {
  try {
    const response = await fetch(`/api/player/${discordId}`);
    const data = await response.json();
    console.log("Resposta da API:", data);

    if (response.ok) {
      document.getElementById("perfil").innerHTML = `
        <h2>Perfil do Jogador</h2>
        <p><strong>Nome:</strong> ${data.nome}</p>
        <p><strong>Saldo:</strong> $${data.saldo.toFixed(2)}</p>
        <p><strong>Nível:</strong> ${data.level}</p>
        <p><strong>EXP:</strong> ${data.exp}</p>
        <p><strong>Conformidade:</strong> ${data.conformidade}</p>
        <p><strong>Moradia:</strong> ${data.moradia}</p>
      `;
    } else {
      document.getElementById("perfil").innerHTML = `
        <p>${data.erro}</p>
      `;
    }
  } catch (error) {
    console.error("Erro ao buscar dados do jogador:", error);
    document.getElementById("perfil").innerHTML = `
      <p>❌ Erro ao carregar os dados do jogador.</p>
    `;
  }
}

const discordId = localStorage.getItem("discord_id");
if (discordId) {
  carregarDadosDoJogador(discordId);
}

window.onload = carregarDados;
