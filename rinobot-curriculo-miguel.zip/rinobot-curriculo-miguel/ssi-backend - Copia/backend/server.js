import express from 'express';
import fetch from 'node-fetch';
import dotenv from 'dotenv';
import cors from 'cors';
import fs from 'fs';
import path from 'path';

dotenv.config();

const app = express();
app.use(cors());

const CLIENT_ID = process.env.DISCORD_CLIENT_ID;
const CLIENT_SECRET = process.env.DISCORD_CLIENT_SECRET;
const REDIRECT_URI = 'http://localhost:3000/auth/discord/callback';

app.get('/auth/discord', (req, res) => {
  const params = new URLSearchParams({
    client_id: CLIENT_ID,
    redirect_uri: REDIRECT_URI,
    response_type: 'code',
    scope: 'identify email'
  });

  res.redirect(`https://discord.com/api/oauth2/authorize?${params.toString()}`);
});

app.get('/auth/discord/callback', async (req, res) => {
  const code = req.query.code;

  try {
    const tokenResponse = await fetch('https://discord.com/api/oauth2/token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: new URLSearchParams({
        client_id: CLIENT_ID,
        client_secret: CLIENT_SECRET,
        grant_type: 'authorization_code',
        code: code,
        redirect_uri: REDIRECT_URI
      })
    });

    const tokenData = await tokenResponse.json();

    if (!tokenData.access_token) {
      return res.status(400).send("Erro ao obter token de acesso.");
    }

    const userResponse = await fetch('https://discord.com/api/users/@me', {
      headers: {
        Authorization: `Bearer ${tokenData.access_token}`
      }
    });

    const userData = await userResponse.json();

    const userEncoded = encodeURIComponent(JSON.stringify(userData));
    const origin = req.headers.origin || 'http://127.0.0.1:5500';
    res.redirect(`${origin}/site/?user=${userEncoded}`);
  } catch (err) {
    console.error("Erro na autenticação Discord:", err);
    res.status(500).send("Erro interno ao autenticar.");
  }
});

// Caminho para o arquivo JSON
const jogadoresPath = path.join(process.cwd(), 'player_data.json');

// Rota para buscar dados do jogador pelo ID do Discord
app.get('/api/player/:id', (req, res) => {
  const id = req.params.id;
  console.log("ID recebido no backend:", id);

  fs.readFile(jogadoresPath, 'utf8', (err, data) => {
    if (err) {
      console.error("Erro ao ler JSON:", err);
      return res.status(500).json({ erro: "Erro ao ler dados" });
    }

    const jogadores = JSON.parse(data);
    const jogador = jogadores[id];
    console.log("Jogador encontrado:", jogador);

    if (!jogador) {
      return res.status(404).json({ 
        erro: "Jogador não encontrado. Use o comando !start para iniciar o jogo." 
      });
    }

    res.json({
      nome: jogador.role,
      saldo: jogador.balance,
      level: jogador.level,
      exp: jogador.exp,
      conformidade: jogador.conformidade,
      moradia: jogador.moradia
    });
  });
});

app.listen(3000, () => {
  console.log('✅ Backend rodando em http://localhost:3000');
});
