from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import firebase_admin
from firebase_admin import credentials, auth

app = FastAPI()

# CORS: Permitir acesso do frontend (ajusta conforme a origem do seu site)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Inicializa Firebase Admin SDK
cred = credentials.Certificate("firebase-adminsdk.json")  # Substitua com o JSON que você exportou do Firebase
firebase_admin.initialize_app(cred)

# Mock de dados do jogador
mock_player_data = {
    "uid123": {
        "nome": "Argo",
        "saldo": 500,
        "nivel": 3,
        "exp": 120,
        "profissao": "Explorador"
    }
}

# Modelo para o retorno
class PlayerData(BaseModel):
    nome: str
    saldo: int
    nivel: int
    exp: int
    profissao: str

# Middleware para verificar o token do Firebase
async def verify_token(request: Request):
    auth_header = request.headers.get("Authorization")
    if not auth_header or not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Token ausente")

    token = auth_header.split(" ")[1]
    try:
        decoded_token = auth.verify_id_token(token)
        uid = decoded_token["uid"]
        return uid
    except:
        raise HTTPException(status_code=401, detail="Token inválido")

# Rota protegida - retorna dados do jogador
@app.get("/api/get-user-data", response_model=PlayerData)
async def get_user_data(uid: str = Depends(verify_token)):
    if uid in mock_player_data:
        return mock_player_data[uid]
    else:
        raise HTTPException(status_code=404, detail="Jogador não encontrado")


from fastapi.staticfiles import StaticFiles

# Servir o conteúdo estático (html, js, css)
app.mount("/", StaticFiles(directory="site", html=True), name="site")

from fastapi.responses import JSONResponse
import json
import os

@app.get("/api/player/{user_id}")
async def get_player(user_id: str):
    file_path = os.path.join("secure", "player_data.json")
    
    if not os.path.exists(file_path):
        return JSONResponse(status_code=404, content={"error": "Arquivo não encontrado"})

    with open(file_path, "r") as f:
        data = json.load(f)

    player = data.get(user_id)
    if player:
        return player
    return JSONResponse(status_code=404, content={"error": "Jogador não encontrado"})

import firebase_admin
from firebase_admin import credentials, auth

# Inicializar Firebase Admin SDK
cred = credentials.Certificate("firebase-adminsdk.json")
firebase_admin.initialize_app(cred)

from fastapi import FastAPI, HTTPException, Depends, Request

app = FastAPI()

@app.post("/verify-token/")
async def verify_token(request: Request):
    body = await request.json()
    token = body.get("idToken")

    if not token:
        raise HTTPException(status_code=400, detail="Token não fornecido.")

    try:
        decoded_token = auth.verify_id_token(token)
        uid = decoded_token['uid']
        return {"status": "Autenticado com sucesso!", "uid": uid}
    except Exception as e:
        raise HTTPException(status_code=401, detail=f"Token inválido: {e}")

from firebase_admin import firestore

db = firestore.client()

# Suponha que você já carregou os dados do JSON:
import json

with open("player_data.json", "r", encoding="utf-8") as f:
    player_data = json.load(f)

# Salvar os dados no Firestore
for uid, data in player_data.items():
    db.collection("players").document(uid).set(data)

with open("guild_data.json", "r", encoding="utf-8") as f:
    guild_data = json.load(f)

for guild_name, data in guild_data["Medalhões"].items():
    db.collection("guilds").document(guild_name).set(data)
