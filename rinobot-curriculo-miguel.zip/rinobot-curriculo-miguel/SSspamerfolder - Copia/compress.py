import shutil

# Caminho da pasta que será compactada
folder_path = "/storage/emulated/0/SSspamerfolder"

# Nome do arquivo ZIP que será criado
output_zip = "/storage/emulated/0/bot.zip"

# Compacta a pasta em um arquivo ZIP
shutil.make_archive(output_zip.replace(".zip", ""), 'zip', folder_path)
print("Arquivo bot.zip criado com sucesso!")
