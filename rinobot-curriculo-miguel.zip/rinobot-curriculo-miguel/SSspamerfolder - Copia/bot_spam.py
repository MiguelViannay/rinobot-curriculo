import discord
from discord.ext import commands, tasks
import random
import asyncio
import json
import os
import time as pytime
import string
from discord.ui import Button, View
from discord import Embed
from datetime import datetime


# O token será obtido a partir das variáveis de ambiente
def get_token():
    try:
        with open('/storage/emulated/0/SSspamerfolder/secure/token.txt', 'r') as token_file:
            return token_file.read().strip()
    except FileNotFoundError:
        print("Erro: arquivo de token não encontrado.")
        return None

TOKEN = get_token()

# Configuração do cliente do bot
intents = discord.Intents.default()
intents.messages = True
intents.message_content = True
intents.guilds = True
bot = commands.Bot(command_prefix='!', intents=intents)

# Arquivos de dados
DATA_FILE = "player_data.json"
GUILD_DATA_FILE = "guild_data.json"
ALLWATER_FILE = "allwater_data.json"
DELTASOFTWARE_FILE = "deltasoftware_data.json"

# Estrutura inicial da ALLwater e DeltaSoftware
INITIAL_ALLWATER = {
    "available": True,
    "current_owner": None,
    "current_value": 300.00,
    "base_value": 300.00
}

INITIAL_DELTASOFTWARE = {
    "available": True,
    "current_owner": None,
    "current_value": 800.00,
    "base_value": 800.00
}

# Funções para manipulação das acoes ALLwater
def save_allwater_data():
    with open(ALLWATER_FILE, "w") as f:
        json.dump(ALLWATER_DATA, f)

def load_allwater_data():
    try:
        with open(ALLWATER_FILE, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return INITIAL_ALLWATER

#2 DeltaSoftware
def save_deltasoftware_data():
    with open(DELTASOFTWARE_FILE, "w") as f:
        json.dump(DELTASOFTWARE_DATA, f)

def load_deltasoftware_data():
    try:
        with open(DELTASOFTWARE_FILE, "r") as f:
            return json.load(f)
    except FileNotFoundError:
        return INITIAL_DELTASOFTWARE

# Carregar dados da ALLwater
ALLWATER_DATA = load_allwater_data()
DELTASOFTWARE_DATA = load_deltasoftware_data()

# Variaveis Globais, Profissoes
# Adicione isto junto com outras variáveis globais
BATTLE_QUEUE = []
ONGOING_BATTLES = {}
MARKET_MODIFIER = 1.0
MARKET_STATUS = "normal"
# Adicione esta lista de climas no topo com as outras variáveis
CLIMAS = [
    "ensolarado", "chuvoso", "nublado", "ventando bastante",
    "com neblina", "com raios e trovões", "ameno",
    "fresco", "com garoa fina", "com arco-íris"
]
# Sistema de Profissões
PROFESSIONS = {
    "contabilidade": {
        "name": "Contabilidade",
        "area": "exatas",
        "min_level": 5,
        "base_income": 5,
        "income_per_level": 1,
        "max_level": 15,
        "interval": 10
    },
    "estatístico": {
        "name": "Estatístico",
        "area": "exatas",
        "min_level": 15,
        "base_income": 15,
        "income_per_level": 2,
        "max_level": 30,
        "interval": 10
    },
    "engenheiro": {
        "name": "Engenheiro",
        "area": "exatas",
        "min_level": 30,
        "base_income": 40,
        "income_per_level": 1.5,
        "max_level": 60,
        "interval": 10
    },
    "biologo": {
        "name": "Biólogo",
        "area": "natureza",
        "min_level": 5,
        "base_income": 5,
        "income_per_level": 1,
        "max_level": 15,
        "interval": 10
    },
    "cientista_amador": {
        "name": "Cientista Amador",
        "area": "natureza",
        "min_level": 15,
        "base_income": 10,
        "income_per_level": 2,
        "max_level": 30,
        "interval": 10
    },
    "medicina": {
        "name": "Medicina",
        "area": "natureza",
        "min_level": 30,
        "base_income": 60,
        "income_per_level": 2,
        "max_level": 60,
        "interval": 10
    }
}

# ID do canal para mensagens automáticas
CHANNEL_ID = 1333291999352324096


# Certifique-se de definir o caminho correto
def load_data():
    """Carrega os dados dos jogadores do arquivo e garante que todos os campos necessários existam."""
    try:
        with open(DATA_FILE, "r") as f:
            data = json.load(f)

            for user_id, user_data in data.items():
                # Garante que o saldo nunca seja negativo
                user_data["balance"] = max(0, user_data.get("balance", 0))
                user_data.setdefault("friends", [])
                user_data.setdefault("pending_requests", [])

                # Inicializa campos obrigatórios
                default_data = {
                    "inventory": {"medalhao": 0, "anti_roubo": 0, "azarao": 0},
                    "medalhao_rounds": 0,
                    "anti_roubo_rounds": 0,
                    "azarao_rounds": 0,
                    "level": 1,
                    "exp": 0,
                    "role": "Sem cargo",
                    "area": None,
                    "profession": None,
                    "last_income": None,
                    "conformidade": 0,
                    "daily": {"last_claimed": None, "streak": 0}
                }

                # Atualiza apenas os campos ausentes
                for key, value in default_data.items():
                    if key not in user_data:
                        user_data[key] = value

                # Garante que o inventário tenha todos os itens necessários
                user_data.setdefault("inventory", {})
                for item, amount in default_data["inventory"].items():
                    user_data["inventory"].setdefault(item, amount)

                # Garante que o empréstimo tenha todos os campos necessários
                
                # Garante que o sistema de recompensa diária tenha todos os campos
                user_data.setdefault("daily", {})
                for key, value in default_data["daily"].items():
                    user_data["daily"].setdefault(key, value)

            return data

    except FileNotFoundError:
        return {}


def save_data(players):
    with open(DATA_FILE, "w") as f:
        json.dump(players, f, indent=4)



# Tarefa de flutuação da ALLwater
@tasks.loop(seconds=10)
async def fluctuate_allwater():
    if ALLWATER_DATA["current_owner"] is not None:
        change = random.uniform(-0.10, 0.10)
        ALLWATER_DATA["current_value"] = round(ALLWATER_DATA["current_value"] * (1 + change), 2)
        save_allwater_data()
        
        
#Tarefa da DeltaSoftware
@tasks.loop(seconds=10)
async def fluctuate_deltasoftware():
    if DELTASOFTWARE_DATA["current_owner"] is not None:
        change = random.uniform(-0.10, 0.10)
        DELTASOFTWARE_DATA["current_value"] = round(DELTASOFTWARE_DATA["current_value"] * (1 + change), 2)
        save_deltasoftware_data()

# Tarefa de Fundos da Gulda
@tasks.loop(seconds=10)
async def gerar_fundo_garantia():
    for guild_name in guilds:
        if guilds[guild_name]["fundo_garantia"] < 200:
            guilds[guild_name]["fundo_garantia"] += 1
    save_guild_data()

# Carregar dados das guildas ao iniciar o bot

GUILD_DATA_FILE = "guild_data.json"

# Carregar os dados das guildas do arquivo JSON
# Garantir que o campo 'membros' existe nas guildas

def load_guild_data():
    try:
        with open(GUILD_DATA_FILE, "r") as f:
            data = json.load(f)

        # Garantir que todas as guildas tenham as chaves necessárias
        for guild in data.values():
            guild.setdefault("membros", [])
            guild.setdefault("in_battle", False)
            guild.setdefault("current_battle", None)
            guild.setdefault("mascote", {})
            guild.setdefault("lider", None)
            guild.setdefault("guild_fund", 0)
            guild.setdefault("meta", 200)
            guild.setdefault("total_arrecadado", 0)
            guild.setdefault("fundo_garantia", 0)
            guild.setdefault("doacoes", {})
            guild.setdefault("contribuicoes", {})

            # Garantir que o mascote tenha os atributos essenciais
            mascote = guild["mascote"]
            if mascote is not None:  # Evita erro se for None
                mascote.setdefault("nivel", 1)
                mascote.setdefault("xp_total", 0)

        return data

    except (FileNotFoundError, json.JSONDecodeError):
        return {}  # Retorna um dicionário vazio se houver erro ao carregar

# Salvar os dados das guildas no arquivo JSON
def save_guild_data():
    with open(GUILD_DATA_FILE, "w") as f:
        json.dump(guilds, f, indent=4)  # Indentação melhora a legibilidade do JSON


def ensure_player_data(user_id):
    """ Garante que todos os campos essenciais existam para um jogador """
    if user_id not in players:
        players[user_id] = {}

    player = players[user_id]

    # Configuração padrão
    default_data = {
        "balance": 0,
        "level": 1,
        "exp": 0,
        "role": "Sem cargo",
        "friends": [],
        "pending_requests": [],
        "moradia": "Nenhuma",
        "conformidade": 0,
        "profession": None,
        "area": None,
        "last_income": None,
        "inventory": {"medalhao": 0, "anti_roubo": 0, "azarao": 0},
        "medalhao_rounds": 0,
        "anti_roubo_rounds": 0,
        "azarao_rounds": 0,
        "daily": {"last_claimed": None, "streak": 0},
        "tag": None
    }

    # Atualiza apenas os campos ausentes
    for key, value in default_data.items():
        player.setdefault(key, value)

    # Garante que o inventário tenha os itens necessários
    for item, amount in default_data["inventory"].items():
        player["inventory"].setdefault(item, amount)


    # Garante que o sistema de recompensa diária tenha todos os campos
    for key, value in default_data["daily"].items():
        player["daily"].setdefault(key, value)

    # Gerar tag única se não existir
    if player["tag"] is None:
        existing_tags = {p["tag"] for p in players.values() if p.get("tag")}
        while True:
            new_tag = "#" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
            if new_tag not in existing_tags:
                player["tag"] = new_tag
                break

    return player



# Carregar dados da ALLwater ao iniciar
def load_allwater_data():
    try:
        with open("allwater_data.json", "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}  # Retorna um dicionário vazio para evitar erro
        
        
# Carregar dados da DeltaSoftWare ao iniciar
def load_deltasoftware_data():
    try:
        with open("deltasoftware_data.json", "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}  # Retorna um dicionário vazio para evitar erro        

# Inicializar os dados dos jogadores e guildas
players = load_data()  # Certifique-se de que load_data() está definida antes
guilds = load_guild_data()



# Função para gerar um novo valor

def generate_new_value(balance, user_id, rejected=False):
    global MARKET_MODIFIER, MARKET_STATUS
    player = players[user_id]

    medalhao_usado = False
    azarao_usado = False

    # Prioridade: Efeito de rejeição (Azarões)
    if rejected:
        if player.get("azarao_rounds", 0) > 0:
            variation = random.uniform(-0.3, 0.6)  # Variação mais arriscada
            player["azarao_rounds"] -= 1
            azarao_usado = True
            message = "🎲 O **Medalhão dos Azares** foi ativado! O destino decidirá sua sorte... ou azar💀🔥"
        else:
            variation = random.uniform(-0.5, 0.5)  # Variação normal para rejeição
            message = "💢 Rejeição anterior afetou o mercado! Cuidado com as próximas ofertas!"
    else:
        # Efeito do Medalhão dos Deuses
        if player.get("medalhao_rounds", 0) > 0:
            variation = random.uniform(0.1, 0.5)  # Apenas positiva
            player["medalhao_rounds"] -= 1
            medalhao_usado = True
            message = "✨ **Medalhão dos Deuses** ativo! Crescimento garantido! 📈"
        else:
            # Variação normal do mercado
            status_variation = {
                "alta": (-0.5, 0.6),
                "baixa": (-0.7, 0.3),
                "volatil": (-0.7, 0.7),
                "estavel": (-0.2, 0.2)
            }
            variation = random.uniform(*status_variation.get(MARKET_STATUS, (-0.5, 0.5)))
            message = None

    # Bônus de moradia
    bonus_moradia = {
        "casa": 0.01,
        "apartamento": 0.03,
        "escritorio": 0.05
    }.get(player.get("moradia", "Nenhuma"), 0)

    # Modificador de conformidade
    conformidade = player.get("conformidade", 0)
    mod_conformidade = (
        1.02 if conformidade >= 90 else
        1.00 if conformidade >= 70 else
        0.97 if conformidade >= 50 else
        0.94 if conformidade >= 30 else
        0.90 if conformidade >= 10 else
        0.80
    )

    # Aplica os modificadores ao cálculo final
    variation = (variation + bonus_moradia) * mod_conformidade * MARKET_MODIFIER
    new_balance = round(balance * (1 + variation), 2)

    return new_balance, message  # Retorna o novo saldo e a mensagem






@bot.command()
@commands.has_permissions(administrator=True)
async def reset_battles(ctx):
    global BATTLE_QUEUE, ONGOING_BATTLES
    
    # Reseta todas as guildas
    for guild in guilds.values():
        guild["in_battle"] = False
    
    # Limpa filas
    BATTLE_QUEUE.clear()
    ONGOING_BATTLES.clear()
    
    # Reseta arquivos
    save_guild_data()
    await ctx.send("✅ Todas as batalhas e status foram resetados!")
# Comando: !guild
@bot.command()
async def guild(ctx):
    user_id = str(ctx.author.id)
    if user_id not in players:
        await ctx.send(f"{ctx.author.mention}, use `!start` primeiro.")
        return

    # Encontra a guilda do jogador
    guild_name = next((name for name, data in guilds.items() if user_id in data.get("membros", [])), None)

    if not guild_name:
        await ctx.send(f"{ctx.author.mention}, você não está em uma guilda. Use `!create [nome]` para criar uma ou `!join [nome]` para entrar em uma existente.")
        return

    # Dados da guilda
    guild_data = guilds[guild_name]

    embed = discord.Embed(
        title=f"🏰 Guilda {guild_name}",
        description=(
            f"**Nível:** {guild_data.get('nivel', 1)}\n"
            f"**Arrecadação Atual:** {guild_data.get('guild_fund', 0)} SS\n"
            f"**Meta para o Próximo Nível:** {guild_data.get('meta', 200)} SS\n"
            f"**Fundo de Garantia:** {guild_data.get('fundo_garantia', 0)}/200 SS\n"
            f"**Total Arrecadado:** {guild_data.get('total_arrecadado', 0)} SS"
        ),
        color=discord.Color.gold()
    )

    # Ranking de doações
    doacoes = guild_data.get("doacoes", {})
    if doacoes:
        ranking = sorted(doacoes.items(), key=lambda x: x[1], reverse=True)
        ranking_message = "\n".join([f"<@{member}>: **{amount:.2f} SS**" for member, amount in ranking])
        embed.add_field(name="🏆 Ranking de Doações", value=ranking_message, inline=False)
    else:
        embed.add_field(name="🏆 Ranking de Doações", value="Nenhuma doação registrada.", inline=False)

    # Lista de membros
    membros = guild_data.get("membros", [])
    if membros:
        embed.add_field(name="👥 Membros", value="\n".join([f"<@{member}>" for member in membros]), inline=False)
    else:
        embed.add_field(name="👥 Membros", value="Nenhum membro na guilda.", inline=False)

    # Seção de batalhas ativas
    battles = [f"`{bid}`" for bid, battle in ONGOING_BATTLES.items() if guild_name in [battle["guild1"], battle["guild2"]]]
    if battles:
        embed.add_field(name="⚔️ Batalhas Ativas", value="\n".join(battles), inline=False)

    # Enviar embed
    try:
        await ctx.send(embed=embed)
    except Exception as e:
        print(f"Erro ao enviar embed: {e}")


# Comando: !guild_donate [quantidade]
@bot.command()
async def guild_donate(ctx, quantidade: float):
    user_id = str(ctx.author.id)
    if user_id not in players:
        await ctx.send(f"{ctx.author.mention}, use `!start` primeiro.")
        return

    # Verifica se o jogador está em uma guilda
    guild_name = None
    for name, data in guilds.items():
        if user_id in data["membros"]:
            guild_name = name
            break

    if not guild_name:
        await ctx.send(f"{ctx.author.mention}, você não está em uma guilda. Use `!create [nome]` para criar uma ou `!join [nome]` para entrar em uma existente.")
        return

    # Verifica se o jogador tem saldo suficiente
    if quantidade <= 0 or quantidade > players[user_id]["balance"]:
        await ctx.send(f"{ctx.author.mention}, valor inválido para doação. Seu saldo atual é {players[user_id]['balance']:.2f} SS.")
        return

    # Realiza a doação
    players[user_id]["balance"] -= quantidade
    guilds[guild_name]["guild_fund"] += quantidade
    guilds[guild_name]["total_arrecadado"] += quantidade

    # Atualiza o ranking de doações
    if "doacoes" not in guilds[guild_name]:
        guilds[guild_name]["doacoes"] = {}
    guilds[guild_name]["doacoes"][user_id] = guilds[guild_name]["doacoes"].get(user_id, 0) + quantidade

    save_data(players)
    save_guild_data()

    await ctx.send(f"🎉 {ctx.author.mention} doou **{quantidade:.2f} SS** para a guilda **{guild_name}**!")

    # Verifica se a guilda atingiu a meta para subir de nível
    if guilds[guild_name]["guild_fund"] >= guilds[guild_name]["meta"]:
        guilds[guild_name]["nivel"] += 1
        guilds[guild_name]["guild_fund"] = 0  # Reseta o fundo
        guilds[guild_name]["meta"] += 200  # Aumenta a meta para o próximo nível
        save_guild_data()
        await ctx.send(f"🚀 A guilda **{guild_name}** subiu para o nível **{guilds[guild_name]['nivel']}**! A nova meta é **{guilds[guild_name]['meta']} SS**.")


# Restante do código (comandos !start, !balance, !shop, etc.) permanece igual
# ...


# Salvar dados das guildas no arquivo JSON
def save_guild_data():
    with open(GUILD_DATA_FILE, "w") as f:
        json.dump(guilds, f)

# Inicializar os dados dos jogadores e guildas
players = load_data()
guilds = load_guild_data()

# !create

@bot.command()
async def create(ctx, nome: str):
    user_id = str(ctx.author.id)
    
    if user_id not in players:
        await ctx.send(f"{ctx.author.mention}, use `!start` primeiro.")
        return

    # Verifica se o jogador já está em uma guilda
    for guild_data in guilds.values():
        if user_id in guild_data["membros"]:
            await ctx.send(f"{ctx.author.mention}, você já está em uma guilda!")
            return

    # Verifica se o nome da guilda já está em uso
    if nome in guilds:
        await ctx.send(f"{ctx.author.mention}, a guilda com o nome `{nome}` já existe!")
        return

    # Criação do mascote
    mascote = {
        "nome": nome,
        "emoji": "🐉",
        "descricao": "Sem descrição",
        "base_ataque_min": random.randint(2, 5),
        "base_ataque_max": random.randint(6, 8),
        "base_vida": random.randint(400, 500),
        "base_defesa": 1.0,
        "ataque": {"level": 1, "xp": 0},
        "defesa": {"level": 1, "xp": 0},
        "vida": {"level": 1, "xp": 0},
        "seguidores": []
    }

    # Criando a guilda e adicionando ao dicionário
    guilds[nome] = {
        "dono": user_id,
        "membros": [user_id],
        "lider": user_id,
        "nivel": 1,
        "guild_fund": 0,
        "meta": 200,
        "total_arrecadado": 0,
        "fundo_garantia": 0,
        "in_battle": False,
        "current_battle": None,
        "mascote": mascote
    }
    
    await ctx.send(f"{ctx.author.mention}, a guilda `{nome}` foi criada com sucesso!")

def get_user_guild(user_id):
    for name, data in guilds.items():
        if user_id in data.get("membros", []):
            return name, data
    return None, None

# Função para gerar ID único de batalha
def generate_battle_id():
    return f"battle_{int(pytime.time())}_{random.randint(1000,9999)}"


#battle start

@bot.command()
async def battle_start(ctx):
    user_id = str(ctx.author.id)
    guild_name, guild = get_user_guild(user_id)
    
    if not guild:
        await ctx.send("❌ Você precisa estar em uma guilda!")
        return
        
    if guild["in_battle"]:
        await ctx.send("⚔️ Sua guilda já está em uma batalha!")
        return
    
    ensure_mascote_data(guild)
    
    if len(BATTLE_QUEUE) >= 1:
        opponent = BATTLE_QUEUE.pop()
        opponent_guild = guilds[opponent["name"]]
        ensure_mascote_data(opponent_guild)
        
        battle_id = generate_battle_id()
        
        ONGOING_BATTLES[battle_id] = {
            "guilds": [guild_name, opponent["name"]],
            "health": {
                guild_name: guild["mascote"]["base_vida"] + (guild["mascote"]["vida"]["level"] * 97),
                opponent["name"]: opponent_guild["mascote"]["base_vida"] + (opponent_guild["mascote"]["vida"]["level"] * 97)
            },
            "attack_order": random.choice([0, 1]),
            "next_attack": pytime.time() + 10,
            "messages": [],
            "channel_id": ctx.channel.id
        }
        
        guild["in_battle"] = True
        guild["current_battle"] = battle_id
        opponent_guild["in_battle"] = True
        opponent_guild["current_battle"] = battle_id
        
        embed = Embed(title=f"⚔️ Batalha {battle_id}", color=0xff0000)
        embed.add_field(name=guild_name, value=f"{guild['mascote']['emoji']} {guild['mascote']['nome']}")
        embed.add_field(name=opponent["name"], value=f"{opponent_guild['mascote']['emoji']} {opponent_guild['mascote']['nome']}")
        await ctx.send(embed=embed)
        
        await battle_loop(battle_id)
    else:
        BATTLE_QUEUE.append({"name": guild_name, "timestamp": pytime.time()})
        await ctx.send("🔎 Procurando oponentes para a batalha...")

async def battle_loop(battle_id):
    battle = ONGOING_BATTLES[battle_id]
    channel = bot.get_channel(battle["channel_id"])

    while True:
        time_to_wait = max(0, battle["next_attack"] - pytime.time())
        await asyncio.sleep(time_to_wait)

        attacker_index = battle["attack_order"]
        attacker_name = battle["guilds"][attacker_index]
        defender_name = battle["guilds"][1 - attacker_index]

        attacker_guild = guilds[attacker_name]
        defender_guild = guilds[defender_name]
        ensure_mascote_data(attacker_guild)
        ensure_mascote_data(defender_guild)

        # Código adicionado
        ataque_min = attacker_guild["mascote"]["base_ataque_min"] + (attacker_guild["mascote"]["ataque"]["level"] * 5)
        ataque_max = attacker_guild["mascote"]["base_ataque_max"] + (attacker_guild["mascote"]["ataque"]["level"] * 6)
        damage = random.randint(ataque_min, ataque_max)

        defesa = defender_guild["mascote"]["base_defesa"] + (defender_guild["mascote"]["defesa"]["level"] * 0.005)
        defesa = min(defesa, 0.5)  # Limite máximo de 50% de redução
        damage = max(1, int(damage * (1 - defesa)))

        battle["health"][defender_name] = max(0, battle["health"][defender_name] - damage)

        embed = Embed(
            title=f"⚔️ {attacker_guild['mascote'].get('emoji', '🐉')} {attacker_guild['mascote'].get('nome', 'Mascote')} atacou!",
            description=f"💥 **Dano**: {damage}\n❤️ **Vida restante de {defender_name}**: {battle['health'][defender_name]}",
            color=0xff0000
        )
        await channel.send(embed=embed)

        if battle["health"][defender_name] <= 0:
            await end_battle(battle_id, attacker_name)
            break

        battle["attack_order"] = 1 - attacker_index
        battle["next_attack"] = pytime.time() + 10




            
            
def ensure_mascote_data(guild):
    if "mascote" not in guild:
        # Criação de novos mascotes com defesa base correta (1%)
        guild["mascote"] = {
            "nome": "Mascote Antigo",
            "emoji": "🦁",
            "descricao": "Mascote legado",
            "base_vida": random.randint(400, 500),
            "base_ataque_min": random.randint(2, 5),
            "base_ataque_max": random.randint(6, 8),
            "base_defesa": 0.01,  # Alterado de 1.0 para 0.01 (1%)
            "vida": {"level": 1, "xp": 0},
            "defesa": {"level": 1, "xp": 0},
            "ataque": {"level": 1, "xp": 0},
            "seguidores": []
        }
    else:
        mascote = guild["mascote"]
        # Garante valores padrão corretos para mascotes existentes
        defaults = {
            "base_vida": 450,
            "base_ataque_min": 3,
            "base_ataque_max": 7,
            "base_defesa": 0.01,  # Alterado de 1.0 para 0.01 (1%)
            "vida": {"level": 1, "xp": 0},
            "defesa": {"level": 1, "xp": 0},
            "ataque": {"level": 1, "xp": 0}
        }
        for key, value in defaults.items():
            if key not in mascote:
                mascote[key] = value
        # Corrige defesa base se estiver errada
        if mascote.get("base_defesa", 0) >= 1.0:
            mascote["base_defesa"] = 0.01
#encerrar batalha:
async def end_battle(battle_id, winner):
    battle = ONGOING_BATTLES.pop(battle_id)
    loser = [g for g in battle["guilds"] if g != winner][0]
    
    for guild_name in battle["guilds"]:
        guild = guilds[guild_name]
        guild["in_battle"] = False
        guild["current_battle"] = None
    
    winner_guild = guilds[winner]
    loser_guild = guilds[loser]
    
    for member in winner_guild["membros"]:
        players[member]["balance"] += 150
    winner_guild["guild_fund"] += 150 * len(winner_guild["membros"])
    winner_guild["total_arrecadado"] += 150 * len(winner_guild["membros"])
    
    for member in loser_guild["membros"]:
        players[member]["balance"] += 20
    loser_guild["guild_fund"] += 20 * len(loser_guild["membros"])
    loser_guild["total_arrecadado"] += 20 * len(loser_guild["membros"])
    
    embed = Embed(
        title=f"🏆 Batalha {battle_id} Concluída!",
        description=f"Vencedor: {winner}\nRecompensa: 150 SS para todos os membros!\nPerdedor: {loser}\nConsolação: 20 SS para todos os membros",
        color=0x00ff00
    )
    embed.set_image(url=f"https://example.com/battle_result?id={battle_id}&winner={winner}")
    
    channel = bot.get_channel(CHANNEL_ID)
    await channel.send(embed=embed)
    
    for msg in battle["messages"]:
        await channel.send(embed=msg)
    
    save_data(players)
    save_guild_data()



@bot.command()
@commands.has_permissions(administrator=True)
async def fix_mascotes(ctx):
    for guild_name in guilds:
        guild = guilds[guild_name]
        if "mascote" in guild:
            guild["mascote"]["base_defesa"] = 0.01
    save_guild_data()
    await ctx.send("✅ Defesa base de todos os mascotes corrigida para 1%!")
# Comando para visualizar status da batalha
@bot.command()
async def battle_info(ctx):
    user_id = str(ctx.author.id)
    guild_name, guild = get_user_guild(user_id)
    
    if not guild or not guild["in_battle"]:
        await ctx.send("ℹ️ Sua guilda não está em nenhuma batalha")
        return
    
    battle = ONGOING_BATTLES.get(guild["current_battle"])
    
    if not battle:
        await ctx.send("⚠️ Batalha não encontrada")
        return
    
    embed = Embed(
        title=f"⚔️ Batalha em Andamento - {guild['current_battle']}",
        color=discord.Color.red()
    )
    
    for guild_name in battle["guilds"]:
        g = guilds[guild_name]
        ensure_mascote_data(g)
        mascote = g["mascote"]
        
        ataque_min = mascote["base_ataque_min"] + (mascote["ataque"]["level"] * 5)
        ataque_max = mascote["base_ataque_max"] + (mascote["ataque"]["level"] * 6)
        
        embed.add_field(
            name=f"{mascote['emoji']} {mascote['nome']} ({guild_name})",
            value=(
                f"❤️ Vida: {battle['health'][guild_name]}\n"
                f"⚔️ Ataque: {ataque_min}-{ataque_max}\n"
                f"🛡️ Defesa: {(mascote['base_defesa'] + (mascote['defesa']['level'] * 0.01)):.2f}%"
            ),
            inline=False
        )
    
    embed.set_footer(text="Próximo ataque em 10 segundos")
    await ctx.send(embed=embed)

    
# Comando: !join [nome_da_guilda]
@bot.command()
async def join(ctx, nome: str):
    user_id = str(ctx.author.id)
    if user_id not in players:
        await ctx.send(f"{ctx.author.mention}, use `!start` primeiro.")
        return

    # Verifica se a guilda existe
    if nome not in guilds:
        await ctx.send(f"{ctx.author.mention}, a guilda **{nome}** não existe.")
        return

    # Verifica se o jogador já está em uma guilda
    for guild_name, guild_data in guilds.items():
        if user_id in guild_data["membros"]:
            await ctx.send(f"{ctx.author.mention}, você já está em uma guilda!")
            return

    # Adiciona o jogador à guilda
    guilds[nome]["membros"].append(user_id)
    save_guild_data()
    await ctx.send(f"🎉 {ctx.author.mention} entrou na guilda **{nome}**!")

# Comando: !leave_guild
@bot.command()
async def leave_guild(ctx):
    user_id = str(ctx.author.id)
    if user_id not in players:
        await ctx.send(f"{ctx.author.mention}, use `!start` primeiro.")
        return

    # Encontra a guilda do jogador
    guild_name = None
    for name, data in guilds.items():
        if user_id in data["membros"]:
            guild_name = name
            break

    if not guild_name:
        await ctx.send(f"{ctx.author.mention}, você não está em uma guilda.")
        return

    # Remove o jogador da guilda
    guilds[guild_name]["membros"].remove(user_id)
    save_guild_data()
    await ctx.send(f"👋 {ctx.author.mention} saiu da guilda **{guild_name}**.")


    # Encontra a guilda do jogador
    guild_name = None
    for name, data in guilds.items():
        if user_id in data["membros"]:
            guild_name = name
            break

    if not guild_name:
        await ctx.send(f"{ctx.author.mention}, você não está em uma guilda. Use `!create [nome]` para criar uma ou `!join [nome]` para entrar em uma existente.")
        return

    # Mostra informações da guilda
    guild_data = guilds[guild_name]
    embed = Embed(
        title=f"🏰 Guilda {guild_name}",
        description=f"Nível: **{guild_data['nivel']}**\nFundo Atual: **{guild_data['guild_fund']} SS**\nMeta para o Próximo Nível: **{guild_data['meta']} SS**\nTotal Arrecadado: **{guild_data['total_arrecadado']} SS**",
        color=discord.Color.gold()
    )
    embed.add_field(name="Membros", value="\n".join([f"<@{member}>" for member in guild_data["membros"]]))
    await ctx.send(embed=embed)

# Comando: !guild_ranked
@bot.command()
async def guild_ranked(ctx):
    # Ordena as guildas pelo total arrecadado
    ranking = sorted(guilds.items(), key=lambda x: x[1]["total_arrecadado"], reverse=True)
    message = "🏆 **Ranking de Guildas**\n"
    for i, (guild_name, guild_data) in enumerate(ranking, 1):
        message += f"{i}. **{guild_name}** - Total Arrecadado: **{guild_data['total_arrecadado']} SS**\n"
    await ctx.send(message)
# ...

# ..

# Função para definir o status do mercado
def set_market_status():
    global MARKET_STATUS, MARKET_MODIFIER

    status = random.choice(["alta", "normal", "baixa", "volatil", "estavel"])
    if status == "alta":
        MARKET_MODIFIER = 1.1  # Aumenta 10% as chances de lucro
    elif status == "normal":
        MARKET_MODIFIER = 1.0  # Sem alterações
    elif status == "baixa":
        MARKET_MODIFIER = 0.7  # Reduz 30% as chances de lucro
    elif status == "volatil":
        MARKET_MODIFIER = 1.3  # Variações extremas
    elif status == "estavel":
        MARKET_MODIFIER = 0.9  # Variações menores

    MARKET_STATUS = status
    return status

# garantir que os jogadores terao banimento
# Corrigir jogadores antigos adicionando chaves ausentes


# Evento: on_ready
@bot.event
async def on_ready():
    global MARKET_STATUS

    print(f'Bot conectado como {bot.user}')
    MARKET_STATUS = set_market_status()

    # Inicia todas as tarefas aqui
    fluctuate_allwater.start()
    fluctuate_deltasoftware.start()
    send_auto_messages.start()
    gerar_fundo_garantia.start()
    passive_income.start()
    atualizar_conformidade.start()
    

    # Mensagem de status do mercado
    channel = bot.get_channel(CHANNEL_ID)
    if channel:
        embed = Embed(
            title="📊 Status do Mercado",
            description=f"O mercado está em **{MARKET_STATUS.capitalize()}**!",
            color=discord.Color.blue()
            )
 
        if MARKET_STATUS == "alta":
            embed.add_field(name="Efeito", value="📈 As chances de lucro aumentaram em 10%! 🚀")
        elif MARKET_STATUS == "baixa":
            embed.add_field(name="Efeito", value="📉 As chances de lucro diminuíram em 30%. 😬")
        elif MARKET_STATUS == "volatil":
            embed.add_field(name="Efeito", value="🎢 O mercado está volátil! Variações extremas de lucro. 🎢")
        elif MARKET_STATUS == "estavel":
            embed.add_field(name="Efeito", value="🛡️ O mercado está estável. Variações menores de lucro. 🛡️")
        else:
            embed.add_field(name="Efeito", value="📊 O mercado está normal. Sem alterações nas chances de lucro. 😐")

        await channel.send(embed=embed)



# info






# Comando: !market
@bot.command()
async def market(ctx):
    embed = Embed(
        title="📊 Status do Mercado",
        description=f"O mercado está em **{MARKET_STATUS.capitalize()}**!",
        color=discord.Color.blue()
    )
    if MARKET_STATUS == "alta":
        embed.add_field(name="Efeito", value="📈 As chances de lucro aumentaram em 10%! 🚀")
    elif MARKET_STATUS == "baixa":
        embed.add_field(name="Efeito", value="📉 As chances de lucro diminuíram em 30%. 😬")
    elif MARKET_STATUS == "volatil":
        embed.add_field(name="Efeito", value="🎢 O mercado está volátil! Variações extremas de lucro. 🎢")
    elif MARKET_STATUS == "estavel":
        embed.add_field(name="Efeito", value="🛡️ O mercado está estável. Variações menores de lucro. 🛡️")
    else:
        embed.add_field(name="Efeito", value="📊 O mercado está normal. Sem alterações nas chances de lucro. 😐")

    await ctx.send(embed=embed)

# Tarefa de mensagens automáticas
@tasks.loop(hours=1)
async def send_auto_messages():
    channel = bot.get_channel(CHANNEL_ID)
    if channel:
        await channel.send("🎮 Continue jogando e investindo com sabedoria! Use `!commands` para ver os comandos disponíveis.")

# Tarefa de variacao de conformidade
@tasks.loop(minutes=60)
async def atualizar_conformidade():
    for user_id in players:
        player = players[user_id]
        moradia = player.get("moradia", "Nenhuma")  # Evita KeyError
        
        if moradia == "casa":
            player["conformidade"] = random.randint(85, 100)
        elif moradia == "apartamento":
            player["conformidade"] = random.randint(60, 70)
        elif moradia == "escritorio":
            player["conformidade"] = random.randint(70, 85)
        else:
            player["conformidade"] = random.randint(30, 50)  # Valor para quem não tem moradia
        
        save_data(players)


#info
@bot.command()
async def info(ctx):
    user_id = str(ctx.author.id)
    
    if user_id not in players:
        await ctx.send(f"{ctx.author.mention}, use `!start` primeiro.")
        return
    
    player = players[user_id]

    # Verifica se a tag existe e se ela é válida
    if not player.get("tag") or len(player["tag"]) != 9:
        player["tag"] = generate_unique_tag(user_id)
        save_data(players)  # Salva os dados para evitar erros futuros

    # Dados do jogador
    balance = player.get("balance", 0)
    medalhao_rounds = player.get("medalhao_rounds", 0)
    anti_roubo_rounds = player.get("anti_roubo_rounds", 0)
    medalhao_count = player.get("inventory", {}).get("medalhao", 0)
    anti_roubo_count = player.get("inventory", {}).get("anti_roubo", 0)
    azarao_count = player.get("inventory", {}).get("azarao", 0)
    azarao_rounds = player.get("azarao_rounds", 0)
    level = player.get("level", 1)
    exp = player.get("exp", 0)
    role = player.get("role", "Sem cargo")
    moradia = player.get("moradia", "Nenhuma") or "Nenhuma"
    conformidade = player.get("conformidade", 0)
    profession = player.get("profession", "Nenhuma") or "Nenhuma"
    area = player.get("area", "Desconhecida") or "Desconhecida"

    # Verifica se o jogador está em uma guilda
    guild_name = next((name for name, data in guilds.items() if user_id in data.get("membros", [])), "Nenhuma")

    # Contagem de amigos
    friends_count = len(player.get("friends", []))

    # Mensagem formatada
    info_message = (
        f"📊 **Informações de {ctx.author.name}**\n"
        f"🏷️ **Tag:** `{player['tag']}`\n"
        f"💵 **Saldo:** {balance:.2f} SS\n"
        f"📈 **Nível:** {level}\n"
        f"🌟 **EXP:** {exp}/{100 * level}\n"
        f"🎭 **Bio:** {role}\n"
        f"🏰 **Guilda:** {guild_name}\n"
        f"🏠 **Moradia:** {moradia.capitalize()}\n"
        f"💺 **Conformidade:** {conformidade}%\n"
        f"👥 **Amigos:** {friends_count} | Use `!friend list` para ver\n"
    )

    # Profissão e área
    prof_data = PROFESSIONS.get(profession, {})
    profession_info = f"🧑‍🔧 **Profissão:** {prof_data.get('name', profession)}"

    if area:
        profession_info += f" (Área: **{area.capitalize()}**)"
    
    profession_info += "\n"

    info_message += profession_info
    
    # Itens e efeitos ativos
    info_message += (
        f"🔮 **Medalhões:** Deuses({medalhao_count}) | Anti-Roubo({anti_roubo_count}) | Azarões({azarao_count})\n"
        f"⏳ **Efeitos Ativos:** +Invest({medalhao_rounds}r) | 🛡️Proteção({anti_roubo_rounds}r) | 🎲Azarão({azarao_rounds}r)\n"
    )
    
    await ctx.send(info_message)




#Gerar tag unica
# Substituir a função generate_unique_tag por:
def generate_unique_tag():
    """Gera tags no formato correto # + 8 caracteres"""
    existing_tags = {p["tag"] for p in players.values() if p.get("tag")}
    while True:
        new_tag = '#' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
        if new_tag not in existing_tags:
            return new_tag


# !tag
@bot.command()
async def tag(ctx, *, tag: str):
    # Normalização da tag
    tag = tag.strip().upper()
    if not tag.startswith('#'):
        tag = '#' + tag

    # Busca com verificação completa
    found = False
    for user_id, player in players.items():
        if player.get("tag", "").upper() == tag:
            try:
                user = await bot.fetch_user(int(user_id))
                username = user.name
            except:
                username = "Usuário Desconhecido"
            
            # Verifica a guilda do jogador
            guild_name = next((name for name, data in guilds.items() if user_id in data.get("membros", [])), "Nenhuma")

            embed = discord.Embed(
                title=f"🔍 Jogador Encontrado: {username}",
                description=f"🏷️ Tag: {player['tag']}",
                color=0x00ff00
            )
            embed.add_field(name="💵 Saldo", value=f"{player['balance']:.2f} SS")
            embed.add_field(name="📈 Nível", value=player['level'])
            embed.add_field(name="🏰 Guilda", value=guild_name, inline=False)  # Adicionando a guilda

            await ctx.send(embed=embed)
            found = True
            break
    
    if not found:
        await ctx.send(f"❌ Nenhum jogador encontrado com a tag `{tag}`")


# Comando: !hello
@bot.command()
async def hello(ctx):
    username = ctx.author.name
    await ctx.send(f"Olá {username}, espero que tudo esteja bem com você!")

# Comando: !start
# Modificar o comando start para garantir o salvamento:
@bot.command()
async def start(ctx):
    user_id = str(ctx.author.id)
    
    if user_id not in players:
        ensure_player_data(user_id)  # Gera a conta e a tag, além dos outros campos padrão
        save_data(players)  # Salva os dados imediatamente
        await ctx.send(f"{ctx.author.mention}, bem-vindo! 🎉 Você recebeu **50.00 SS** para começar. 🏷️ **Sua tag é:** `{players[user_id]['tag']}`")
    else:
        await ctx.send(f"{ctx.author.mention}, você já tem uma conta! 🏷️ **Sua tag é:** `{players[user_id]['tag']}`")


    
#tarefa


# Comando: !balance
@bot.command()
async def balance(ctx):
    user_id = str(ctx.author.id)
    if user_id in players:
        balance = round(players[user_id]["balance"], 2)
        await ctx.send(f"{ctx.author.mention}, seu saldo atual é {balance:.2f} SS.")
    else:
        await ctx.send(f"{ctx.author.mention}, você não tem uma conta ativa. Use `!start` para começar.")


#shop
@bot.command()
async def shop(ctx):
    shop_items = """
**🛒 Loja**
1️⃣ **Medalhão dos Deuses** - Melhora investimentos por 3 rodadas
   💰 Preço: 120 SS | Use `!buy medalhao`

2️⃣ **Medalhão Anti-Roubo** - Bloqueia roubos por 3 rodadas
   💰 Preço: 100 SS | Use `!buy anti_roubo`
   
3️⃣ **Medalhão dos Azarões** - Melhora chances após rejeições  
   💰 Preço: 110 SS | Use `!buy azarao`

♒️**ALLwater** - Ação variável a cada 10s
   💵 Valor Atual: {allwater_value} SS
   {allwater_status} | Compre com `!buy ALLwater`

💻 **DeltaSoftware** - Ação tecnológica em constante evolução
   💵 Valor Atual: {deltasoftware_value} SS
   {deltasoftware_status} | Compre com `!buy DeltaSoftware`
""".format(
        allwater_value=ALLWATER_DATA["base_value"] if ALLWATER_DATA["available"] else ALLWATER_DATA["current_value"],
        allwater_status="🟢 DISPONÍVEL" if ALLWATER_DATA["available"] else "🔴 VENDIDA",
        deltasoftware_value=DELTASOFTWARE_DATA["base_value"] if DELTASOFTWARE_DATA["available"] else DELTASOFTWARE_DATA["current_value"],
        deltasoftware_status="🟢 DISPONÍVEL" if DELTASOFTWARE_DATA["available"] else "🔴 VENDIDA"
    )
    await ctx.send(shop_items)



# Atualize o comando !buy
@bot.command()
async def buy(ctx, item: str):
    user_id = str(ctx.author.id)

    # Garante que o jogador existe e tem um inventário configurado corretamente
    player = ensure_player_data(user_id)

    # Dicionário de preços dos itens disponíveis
    prices = {
        "medalhao": 120,
        "anti_roubo": 100,
        "azarao": 110
    }

    # Verifica se o item existe na loja
    item = item.lower()
    if item in prices:
        price = prices[item]

        if player["balance"] >= price:
            # Garante que o item existe no inventário do jogador
            if item not in player["inventory"]:
                player["inventory"][item] = 0  # Inicializa o item se não existir

            player["balance"] -= price
            player["inventory"][item] += 1
            save_data(players)

            nomes_itens = {
                "medalhao": "**Medalhão dos Deuses**",
                "anti_roubo": "**Medalhão Anti-Roubo**",
                "azarao": "**Medalhão dos Azarões**"
            }

            await ctx.send(f"{ctx.author.mention}, você comprou um {nomes_itens[item]}! Use `!use {item}` para ativá-lo.")
        else:
            await ctx.send(f"{ctx.author.mention}, saldo insuficiente!")

        return

    # Compra da ALLwater (caso especial)
    if item == "allwater":
        if not ALLWATER_DATA["available"]:
            await ctx.send(f"{ctx.author.mention} ❌ A ALLwater já foi vendida!")
            return

        price = ALLWATER_DATA["base_value"]
        if player["balance"] >= price:
            player["balance"] -= price
            ALLWATER_DATA["available"] = False
            ALLWATER_DATA["current_owner"] = user_id
            ALLWATER_DATA["current_value"] = price
            save_data(players)
            save_allwater_data()

            await ctx.send(f"🎉 {ctx.author.mention} comprou a ALLwater por {price} SS!")
        else:
            await ctx.send(f"{ctx.author.mention} ❌ Saldo insuficiente!")

        return

    # Compra da DeltaSoftware (caso especial)
    if item == "deltasoftware":
        if not DELTASOFTWARE_DATA["available"]:
            await ctx.send(f"{ctx.author.mention} ❌ A DeltaSoftware já foi vendida!")
            return

        price = DELTASOFTWARE_DATA["base_value"]
        if player["balance"] >= price:
            player["balance"] -= price
            DELTASOFTWARE_DATA["available"] = False
            DELTASOFTWARE_DATA["current_owner"] = user_id
            DELTASOFTWARE_DATA["current_value"] = price
            save_data(players)
            save_deltasoftware_data()

            await ctx.send(f"💻 {ctx.author.mention} comprou a DeltaSoftware por {price} SS!")
        else:
            await ctx.send(f"{ctx.author.mention} ❌ Saldo insuficiente!")

        return

    # Se o item não existir
    await ctx.send(f"{ctx.author.mention}, item inválido!")





# !use item
@bot.command()
async def use(ctx, item: str):
    user_id = str(ctx.author.id)

    # Garante que o jogador exista e tenha inventário configurado corretamente
    player = ensure_player_data(user_id)

    # Dicionário de efeitos dos itens
    effects = {
        "medalhao": {"rounds": "medalhao_rounds", "message": "✨ Melhorias nas ofertas por 3 rodadas!"},
        "anti_roubo": {"rounds": "anti_roubo_rounds", "message": "🛡️ Proteção contra roubos por 3 rodadas!"},
        "azarao": {"rounds": "azarao_rounds", "message": "🎲 Melhores chances após rejeições por 3 rodadas!"}
    }

    item = item.lower()

    if item in effects:
        if player["inventory"].get(item, 0) > 0:
            player["inventory"][item] -= 1
            player[effects[item]["rounds"]] = 3  # Ativa por 3 rodadas
            save_data(players)
            await ctx.send(f"{ctx.author.mention}, você ativou o **{item.capitalize()}**! {effects[item]['message']}")
        else:
            await ctx.send(f"{ctx.author.mention}, você não tem esse item.")
    else:
        await ctx.send(f"{ctx.author.mention}, item inválido!")




# Função para iniciar o investimento
async def start_investment(ctx, amount):
    """Inicia um investimento de 3 rodadas, permitindo aceitar ou rejeitar valores gerados."""
    user_id = str(ctx.author.id)
    
    # Garante que o jogador tenha os campos necessários
    player = ensure_player_data(user_id)
    
    # Inicializa o valor do investimento
    player["current_value"] = amount
    save_data(players)
    
    for rodada in range(1, 4):  # Loop para 3 rodadas
        current_value = player["current_value"]
        if current_value is None:  # Se o investimento foi aceito ou perdido
            break
        
        # Passe o parâmetro rejected baseado na rodada anterior
        rejected = (rodada > 1)  # Assume rejeição se não for a primeira rodada
        new_value, message = generate_new_value(current_value, user_id, rejected)
        
        player["current_value"] = new_value
        save_data(players)
        
        # Construir a mensagem de informação
        info_message = f"💰 Rodada {rodada}/3 - Novo valor gerado: {new_value:.2f} SS."
        if message:
            info_message += f"\n{message}"  # Adiciona a mensagem especial
        
        await ctx.send(info_message)

        # Mensagens de instrução
        if rodada < 3:
            await ctx.send("Use `!accept` para aceitar ou `!reject` para rejeitar.")
        else:
            await ctx.send("Última rodada! Use `!accept` para aceitar.")

        try:
            def check(m):
                valid_commands = ["!accept"]
                if rodada < 3:
                    valid_commands.append("!reject")
                return m.author == ctx.author and m.channel == ctx.channel and m.content.lower() in valid_commands
            
            msg = await bot.wait_for('message', check=check, timeout=25)

            if msg.content.lower() == '!accept':
                player["balance"] += player["current_value"]
                final_value = player["current_value"]
                player["current_value"] = None
                save_data(players)
                await ctx.send(f"✅ Aceito! Saldo final: {final_value:.2f} SS. Saldo total: {player['balance']:.2f} SS.")
                return
            
            elif msg.content.lower() == '!reject' and rodada < 3:
                await ctx.send(f"❌ Rejeitado. Restam {3 - rodada} rodadas.")
                continue  # Continua para a próxima rodada
        
        except asyncio.TimeoutError:
            if rodada == 3:
                # Forçar aceitação na terceira rodada
                player["balance"] += player["current_value"]
                final_value = player["current_value"]
                player["current_value"] = None
                save_data(players)
                await ctx.send(f"⏰ Tempo esgotado! Valor final de {final_value:.2f} SS creditado.")
            else:
                player["current_value"] = None
                save_data(players)
                await ctx.send("⏰ Tempo esgotado. Investimento perdido.")
            return



    
    # Caso todas as rodadas tenham sido rejeitadas (impossível devido à terceira rodada)
    if player["current_value"] is not None:
        player["balance"] += player["current_value"]
        final_value = player["current_value"]
        player["current_value"] = None
        save_data(players)
        await ctx.send(f"⏰ Rodadas esgotadas! {final_value:.2f} SS creditados.")


# Comando: !deposit
@bot.command()
async def deposit(ctx, amount: float):
    user_id = str(ctx.author.id)
    
    if user_id not in players:
        await ctx.send(f"{ctx.author.mention}, use `!start` primeiro.")
        return
    
    player = players[user_id]

    # Verificar saldo suficiente
    if amount <= 0 or amount > player["balance"]:
        await ctx.send(f"{ctx.author.mention}, valor inválido ou saldo insuficiente.")
        return

    # Chance de roubo por um jogador imaginário (30%)
    if random.random() < 0.3:
        # Verifica se o jogador tem o Medalhão Anti-Roubo
        if player.get("anti_roubo_rounds", 0) > 0:
            player["anti_roubo_rounds"] -= 1
            await ctx.send(f"🛡️ Seu Medalhão Anti-Roubo bloqueou um roubo imaginário! Rodadas restantes: {player['anti_roubo_rounds']}")
        else:
            stolen_amount = round(amount * 0.2, 2)  # 20% é roubado
            recovered_amount = round(amount * 0.8, 2)  # 80% é recuperado
            player["balance"] -= stolen_amount
            save_data(players)
            await ctx.send(f"🚨 {ctx.author.mention}, um jogador imaginário roubou {stolen_amount:.2f} SS! Você conseguiu recuperar {recovered_amount:.2f} SS.")
        
        return  # Finaliza o comando após o roubo ou bloqueio

    # Adicionar 20 EXP ao jogador
    player["exp"] = player.get("exp", 0) + 20
    
    # Verifica se o jogador subiu de nível
    exp_needed = 100 * player.get("level", 1)
    if player["exp"] >= exp_needed:
        player["level"] = player.get("level", 1) + 1
        player["exp"] = 0  # Reseta a EXP
        await ctx.send(f"🎉 {ctx.author.mention} subiu para o nível **{player['level']}**!")

        # Se atingir o nível 20 e ainda não tiver moradia, sugere escolher
        if player["level"] == 20 and not player.get("moradia"):
            await ctx.send(f"🎉 {ctx.author.mention}, você alcançou o nível 20! Use `!escolher_moradia [casa|apartamento|escritorio]`.")

    # Contabiliza transação para possível cobrança bancária
    player["transactions_count"] = player.get("transactions_count", 0) + 1
    if player["transactions_count"] >= 10:
        await charge_bank_fee(ctx, user_id)

    # Inicia o ciclo de investimento
    player["balance"] -= amount
    player["current_value"] = round(amount, 2)
    save_data(players)
    
    await ctx.send(f"{ctx.author.mention} depositou {amount:.2f} SS. Iniciando 3 rodadas de investimento...")
    await start_investment(ctx, amount)





            
# Comando: !ranked
@bot.command()
async def ranked(ctx):
    ranking = sorted(players.items(), key=lambda x: x[1]["balance"], reverse=True)
    message = "**🏆 Ranking do Servidor**:\n"
    for i, (user_id, data) in enumerate(ranking, 1):
        message += f"{i}. <@{user_id}> - {data['balance']:.2f} SS\n"
    await ctx.send(message)

# Comando: !reset_all (somente para admin)
@bot.command()
@commands.has_permissions(administrator=True)
async def reset_all(ctx):
    global players
    for user_id in players:
        players[user_id]["balance"] = 50.00
        players[user_id]["current_value"] = None
    save_data()
    await ctx.send("⚠️ Todos os jogadores foram resetados e agora possuem 50.00 SS.")
    
# Comando: !role (Adiciona uma descrição na info)
@bot.command()
async def role(ctx, *, new_role: str):
    user_id = str(ctx.author.id)
    if user_id not in players:
        await ctx.send(f"{ctx.author.mention}, use `!start` primeiro.")
        return

    # Define o novo cargo
    players[user_id]["role"] = new_role
    save_data(players)
    await ctx.send(f"🎭 {ctx.author.mention}, seu cargo foi atualizado para **{new_role}**!")
    
    
# Novo comando !sell
@bot.command()
async def sell(ctx, item: str):
    user_id = str(ctx.author.id)
    
    # Venda da ALLwater
    if item.lower() == "allwater":
        if ALLWATER_DATA["current_owner"] != user_id:
            await ctx.send(f"{ctx.author.mention} ❌ Você não é dono da ALLwater!")
            return
            
        # Calcula valor atual
        current_value = ALLWATER_DATA["current_value"]
        
        # Retorna 95% do valor para balance (5% de taxa)
        sale_price = round(current_value * 0.95, 2)
        players[user_id]["balance"] += sale_price
        
        # Atualiza dados
        ALLWATER_DATA["available"] = True
        ALLWATER_DATA["base_value"] = current_value  # Novo preço base
        ALLWATER_DATA["current_owner"] = None
        save_data(players)
        save_allwater_data()
        
        await ctx.send(f"📉 {ctx.author.mention} vendeu a ALLwater por {sale_price} SS!")
        return

    # Venda da DeltaSoftware
    if item.lower() == "deltasoftware":
        if DELTASOFTWARE_DATA["current_owner"] != user_id:
            await ctx.send(f"{ctx.author.mention} ❌ Você não é dono da DeltaSoftware!")
            return
            
        # Calcula valor atual
        current_value = DELTASOFTWARE_DATA["current_value"]
        
        # Retorna 95% do valor para balance (5% de taxa)
        sale_price = round(current_value * 0.95, 2)
        players[user_id]["balance"] += sale_price
        
        # Atualiza dados
        DELTASOFTWARE_DATA["available"] = True
        DELTASOFTWARE_DATA["base_value"] = current_value  # Novo preço base
        DELTASOFTWARE_DATA["current_owner"] = None
        save_data(players)
        save_deltasoftware_data()
        
        await ctx.send(f"💻 {ctx.author.mention} vendeu a DeltaSoftware por {sale_price} SS!")
        return

    # Se o item não existir
    await ctx.send(f"{ctx.author.mention}, item inválido para venda!")


#Actions_stats
@bot.command()
async def actions_stats(ctx):
    # Garante que as variáveis existem antes de acessá-las
    allwater_value = ALLWATER_DATA.get("current_value", "N/A")
    allwater_owner = ALLWATER_DATA.get("current_owner")
    delta_value = DELTASOFTWARE_DATA.get("current_value", "N/A")
    delta_owner = DELTASOFTWARE_DATA.get("current_owner")

    stats = f"""
**📊 Estatísticas das Ações**

💧 **ALLwater**
   Valor Atual: {allwater_value} SS
   {"Dono: <@" + str(allwater_owner) + ">" if allwater_owner else "Disponível na Loja"}
   Próxima Atualização: a cada 10 segundos

💻 **DeltaSoftware**
   Valor Atual: {delta_value} SS
   {"Dono: <@" + str(delta_owner) + ">" if delta_owner else "Disponível na Loja"}
   Próxima Atualização: a cada 10 segundos
"""
    await ctx.send(stats)



@bot.command()
async def collect(ctx):
    user_id = str(ctx.author.id)
    
    # Verificar se está em uma guilda
    guilda_usuario = None
    for nome, dados in guilds.items():
        if user_id in dados["membros"]:
            guilda_usuario = nome
            break
            
    if not guilda_usuario:
        await ctx.send("❌ Você precisa estar em uma guilda para coletar o fundo!")
        return
        
    fundo = guilds[guilda_usuario]["fundo_garantia"]
    
    if fundo <= 0:
        await ctx.send("⚠️ O fundo de garantia está vazio!")
        return
    
    # Adicionar o valor ao jogador e zerar o fundo
    players[user_id]["balance"] += fundo
    guilds[guilda_usuario]["fundo_garantia"] = 0
    save_data(players)
    save_guild_data()
    
    await ctx.send(f"🎉 {ctx.author.mention} coletou {fundo} SS do fundo de garantia da guilda!")




        
        


# Comando para resgatar diário
@bot.command()
async def diario(ctx):
    user_id = str(ctx.author.id)
    now = pytime.time()

    # Garantir que o jogador existe e tem a estrutura correta
    if user_id not in players:
        await ctx.send("❌ Você ainda não iniciou sua conta! Use `!start` para começar.")
        return
    
    if "daily" not in players[user_id]:  # Se for um jogador antigo, adiciona o campo "daily"
        players[user_id]["daily"] = {
            "last_claimed": None,
            "streak": 0
        }

    # Verificar se já resgatou hoje
    last = players[user_id]["daily"]["last_claimed"]
    if last and (now - last) < 86400:  # 24 horas
        await ctx.send("⏳ Você já resgatou seu prêmio hoje! Volte amanhã.")
        return
    
    # Atualizar dados
    players[user_id]["daily"]["streak"] += 1
    players[user_id]["daily"]["last_claimed"] = now
    
    # Calcular recompensa
    streak = players[user_id]["daily"]["streak"]
    recompensa = 50 + (10 * streak)  # Base 50 + 10 por dia consecutivo
    
    # Bônus especial para streaks de 7 dias
    if streak % 7 == 0:
        recompensa *= 2
        players[user_id]["inventory"]["medalhao"] += 1  # Adiciona medalhão
    
    players[user_id]["balance"] += recompensa
    save_data(players)
    
    # Criar embed de resposta
    embed = discord.Embed(
        title="🎁 Recompensa Diária",
        description=f"Você resgatou **{recompensa} SS**!\n"
                    f"Sequência atual: {streak} dias {'🔥' * min(streak, 5)}",
        color=0x00ff00
    )
    if streak % 7 == 0:
        embed.add_field(name="🌟 Bônus Semanal!", value="Você ganhou um Medalhão dos Deuses!", inline=False)
    
    await ctx.send(embed=embed)

#Profissoes
@bot.command()
async def professions(ctx):
    embed = Embed(
        title="📚 Sistema de Profissões",
        description="Escolha uma profissão com `!choose_profession [área] [profissão]`\n",
        color=discord.Color.blue()
    )
    
    exatas_desc = []
    natureza_desc = []
    
    for key, prof in PROFESSIONS.items():
        line = (
            f"**{prof['name']}**\n"
            f"> Nível {prof['min_level']}-{prof['max_level']}\n"
            f"> Ganho: {prof['base_income']} SS + {prof['income_per_level']}/nível\n"
            f"> Intervalo: {prof['interval']}s\n"
        )
        if prof["area"] == "exatas":
            exatas_desc.append(line)
        else:
            natureza_desc.append(line)
    
    embed.add_field(name="🔢 Área de Exatas", value="\n".join(exatas_desc), inline=False)
    embed.add_field(name="🌿 Área de Natureza", value="\n".join(natureza_desc), inline=False)
    
    await ctx.send(embed=embed)
    
    


# Novos comandos:
@bot.command()
async def friend(ctx, action: str = None, tag: str = None):
    user_id = str(ctx.author.id)
    player = ensure_player_data(user_id)
    
    if not action:
        await ctx.send("Uso: !friend [add/accept/reject/list]")
        return
    
    action = action.lower()
    
    if action == "add":
        if not tag or not tag.startswith('#'):
            await ctx.send("Use: !friend add #[TAG]")
            return
            
        # Encontrar jogador pela tag
        target = next((uid for uid, p in players.items() if p["tag"] == tag.upper()), None)
        
        if not target:
            await ctx.send("❌ Tag não encontrada!")
            return
            
        if target == user_id:
            await ctx.send("❌ Não pode adicionar a si mesmo!")
            return
            
        # Enviar solicitação
        target_player = players[target]
        if user_id in target_player["pending_requests"]:
            await ctx.send("⏳ Solicitação já enviada!")
            return
            
        target_player["pending_requests"].append(user_id)
        save_data(players)
        
        # Enviar DM
        try:
            target_user = await bot.fetch_user(int(target))
            embed = Embed(
                title="📨 Solicitação de Amizade",
                description=f"{ctx.author.name} quer ser seu amigo!",
                color=0x00ff00
            )
            embed.add_field(name="Aceitar", value="`!friend accept " + player["tag"] + "`")
            embed.add_field(name="Recusar", value="`!friend reject " + player["tag"] + "`")
            await target_user.send(embed=embed)
            await ctx.send("✅ Solicitação enviada!")
        except:
            await ctx.send("⚠️ Não foi possível enviar DM para o jogador!")

    elif action in ["accept", "reject"]:
        if not tag:
            await ctx.send("Use: !friend accept #[TAG]")
            return
            
        sender = next((uid for uid, p in players.items() if p["tag"] == tag.upper()), None)
        
        if not sender:
            await ctx.send("❌ Tag inválida!")
            return
            
        if sender not in player["pending_requests"]:
            await ctx.send("❌ Solicitação não encontrada!")
            return
            
        player["pending_requests"].remove(sender)
        
        if action == "accept":
            player["friends"].append(sender)
            players[sender]["friends"].append(user_id)
            await ctx.send(f"🎉 Você e <@{sender}> agora são amigos!")
        else:
            await ctx.send("❌ Solicitação recusada!")
            
        save_data(players)
        
    elif action == "list":
        friends = [f"<@{uid}>" for uid in player["friends"]]
        embed = Embed(
            title="👥 Lista de Amigos",
            description="\n".join(friends) if friends else "Nenhum amigo :(",
            color=0x00ff00
        )
        await ctx.send(embed=embed)
#Choose profession
@bot.command()
async def choose_profession(ctx, area: str = None, profession: str = None):
    user_id = str(ctx.author.id)

    # Verificar se os argumentos foram fornecidos
    if area is None or profession is None:
        await ctx.send("❌ Uso correto: `!choose_profession [área] [profissão]`\nUse `!professions` para ver as opções.")
        return

    if user_id not in players:
        await ctx.send(f"{ctx.author.mention}, use `!start` primeiro.")
        return

    profession = profession.lower()
    area = area.lower()

    if profession not in PROFESSIONS:
        await ctx.send("❌ Profissão inválida! Use `!professions` para ver as opções.")
        return

    prof_data = PROFESSIONS[profession]

    if prof_data["area"] != area:
        await ctx.send(f"❌ {prof_data['name']} pertence à área de **{prof_data['area'].capitalize()}**, não {area.capitalize()}!")
        return

    level = players[user_id]["level"]
    if not (prof_data["min_level"] <= level <= prof_data["max_level"]):
        await ctx.send(f"❌ Essa profissão requer nível entre {prof_data['min_level']} e {prof_data['max_level']}!")
        return

    # Atualiza a profissão do jogador
    players[user_id].update({
        "area": area,
        "profession": profession,
        "last_income": pytime.time()
    })
    save_data(players)

    await ctx.send(f"🎉 Parabéns, {ctx.author.mention}! Você agora é um **{prof_data['name']}** na área de **{area.capitalize()}**!")

# Loop para gerar renda passiva
@tasks.loop(seconds=1)
async def passive_income():
    current_time = pytime.time()
    
    for user_id, player in players.items():
        try:
            if not player.get("profession"):
                continue

            prof_data = PROFESSIONS.get(player["profession"])
            if not prof_data:
                continue

            level = player["level"]
            if not (prof_data["min_level"] <= level <= prof_data["max_level"]):
                continue

            elapsed = current_time - player.get("last_income", 0)
            if elapsed >= prof_data["interval"]:
                # Calcular rendimento
                level_diff = level - prof_data["min_level"]
                income = prof_data["base_income"] + (level_diff * prof_data["income_per_level"])

                # Atualizar saldo e último pagamento
                player["balance"] += income
                player["last_income"] = current_time
                save_data(players)

        except Exception as e:
            print(f"Erro em passive_income: {e}")



# Transferencia para outros jogadores
@bot.command()
async def transferir(ctx, membro: discord.Member = None, valor: float = None):
    # Verificar se os parâmetros foram fornecidos
    if membro is None or valor is None:
        await ctx.send("❌ Uso correto: `!transferir @membro [valor]`")
        return

    user_id = str(ctx.author.id)
    target_id = str(membro.id)

    # Verificações iniciais
    if user_id not in players:
        await ctx.send(f"{ctx.author.mention}, você precisa ter uma conta! Use `!start`")
        return
        
    if target_id not in players:
        await ctx.send(f"{membro.mention} não tem uma conta! Peça para ele usar `!start`")
        return
        
    if valor <= 0:
        await ctx.send("❌ O valor da transferência deve ser positivo!")
        return
        
    if user_id == target_id:
        await ctx.send("❌ Você não pode transferir para si mesmo!")
        return

    # Verificar relações
    is_friend = target_id in players[user_id].get("friends", [])
    same_guild_flag = same_guild(user_id, target_id)  # Função para checar guilda

    # Definir taxas
    if same_guild_flag:
        taxa_percent = 0.20  # 20% de taxa para mesma guilda
    elif is_friend:
        taxa_percent = 0.30  # 30% de taxa para amigos
    else:
        taxa_percent = 0.40  # 40% de taxa padrão

    # Cálculos
    taxa_banco = round(valor * taxa_percent, 2)
    valor_recebido = round(valor * (1 - taxa_percent), 2)
    custo_total = round(valor, 2)

    # Verificar saldo suficiente
    if players[user_id]["balance"] < custo_total:
        await ctx.send(f"❌ Saldo insuficiente! Você precisa de **{custo_total:.2f} SS**")
        return

    # Executar transferência
    players[user_id]["balance"] -= custo_total
    players[target_id]["balance"] += valor_recebido
    save_data(players)

    # Criar embed de confirmação
    embed = discord.Embed(
        title="💸 Transferência Bancária",
        description=f"💰 **{ctx.author.mention} enviou dinheiro para {membro.mention}!**",
        color=0x00ff00
    )
    embed.add_field(name="💵 Valor Original", value=f"{valor:.2f} SS", inline=True)
    embed.add_field(name="🏦 Taxa do Banco", value=f"-{taxa_banco:.2f} SS", inline=True)
    embed.add_field(name="📥 Valor Recebido", value=f"+{valor_recebido:.2f} SS", inline=True)

    # Mensagem personalizada
    if same_guild_flag:
        embed.description += "\n🏰 **Membros da mesma guilda! Taxa reduzida para 20%**"
    elif is_friend:
        embed.description += "\n🤝 **Transferência entre amigos! Taxa reduzida para 30%**"

    embed.set_footer(text="Obrigado por usar nosso sistema bancário!")

    await ctx.send(embed=embed)

# Função para verificar se dois jogadores estão na mesma guilda
def same_guild(user1_id, user2_id):
    guild1 = next((name for name, data in guilds.items() if user1_id in data["membros"]), None)
    guild2 = next((name for name, data in guilds.items() if user2_id in data["membros"]), None)
    return guild1 is not None and guild1 == guild2




# Comando moradia
@bot.command()
async def escolher_moradia(ctx, tipo: str = None):
    if tipo is None:
        await ctx.send("Voce deve adicionar um parametro no comando, exemplo: `!escolher_moradia casa, apartamento ou escritorio`")
        return
    
    user_id = str(ctx.author.id)
    if players[user_id]["level"] < 20:
        await ctx.send("❌ Você precisa ser nível 20 para escolher uma moradia!")
        return
    
    tipo = tipo.lower()
    if tipo not in ["casa", "apartamento", "escritorio"]:
        await ctx.send("❌ Opções válidas: casa, apartamento, escritorio")
        return
    
    players[user_id]["moradia"] = tipo
    # Define conformidade inicial
    if tipo == "casa":
        players[user_id]["conformidade"] = random.randint(85, 100)
    elif tipo == "apartamento":
        players[user_id]["conformidade"] = random.randint(60, 70)
    else:
        players[user_id]["conformidade"] = random.randint(70, 85)
    
    save_data(players)
    await ctx.send(f"🏡 Moradia definida como **{tipo.capitalize()}**! Conformidade atual: {players[user_id]['conformidade']}%")

#Niveis de conformidade:
@bot.command()
async def conformidade(ctx):
    user_id = str(ctx.author.id)

    # Verifica se o jogador está registrado
    if user_id not in players:
        await ctx.send(f"{ctx.author.mention}, use `!start` primeiro.")
        return

    player = players[user_id]
    moradia = player.get("moradia", "Nenhuma")  # Evita KeyError
    conformidade = player.get("conformidade", 50)  # Valor padrão se não existir

    # Define o bônus no depósito com base na moradia
    bonus_moradia = {
        "casa": "1%",
        "apartamento": "3%",
        "escritorio": "5%"
    }.get(moradia, "0%")  # Se não tiver moradia, sem bônus

    # Calcula o modificador de mercado
    modificador_mercado = round(((generate_new_value(100, user_id)[0]) / 100 - 1) * 100, 2)

    # Criando o embed formatado
    embed = discord.Embed(
        title="💺 Níveis de Conforto",
        description=f"🏠 Moradia: **{moradia.capitalize()}**\n"
                    f"📊 Conformidade Atual: **{conformidade}%**",
        color=0x00ff00
    )
    embed.add_field(
        name="📈 Efeitos Ativos",
        value=f"💰 Bônus no Depósito: **{bonus_moradia}**\n"
              f"📉 Modificador de Mercado: **{modificador_mercado}%**"
    )

    await ctx.send(embed=embed)


# !time
@bot.command()
async def time(ctx):
    now = datetime.now()
    hora_atual = now.hour
    clima = random.choice(CLIMAS)
    
    # Determinar período do dia
    if 4 <= hora_atual < 12:
        saudacao = "Bom dia"
        mensagem = "ótimo para fazer alguns investimentos! ☀️"
    elif 12 <= hora_atual < 18:
        saudacao = "Boa tarde"
        mensagem = "aproveite para tomar um café e analisar o mercado! ☕"
    else:
        saudacao = "Boa noite"
        mensagem = "hora de revisar seus ganhos e planejar o amanhã! 🌙"

    # Formatar hora no estilo brasileiro
    hora_formatada = now.strftime("%H:%M")
    
    embed = Embed(
        title=f"⏰ Relógio Econômico ({hora_formatada})",
        description=f"{saudacao}, {ctx.author.mention}!",
        color=discord.Color.gold()
    )
    embed.add_field(
        name="🌤️ Condições Atuais",
        value=f"Hoje o clima está **{clima}**,\n{mensagem}",
        inline=False
    )
    
    await ctx.send(embed=embed)

# !steal
@bot.command()
async def steal(ctx, target: discord.Member):
    user_id = str(ctx.author.id)
    target_id = str(target.id)
    
    if user_id not in players or target_id not in players:
        await ctx.send("❌ Um dos jogadores não está registrado!")
        return
        
    if user_id == target_id:
        await ctx.send("❌ Você não pode roubar a si mesmo!")
        return
        
    ladrao = players[user_id]
    vitima = players[target_id]
    
    if players[target_id].get("anti_roubo_rounds", 0) > 0:
        players[target_id]["anti_roubo_rounds"] -= 1
        await ctx.send(
            f"🛡️ {target.mention} está protegido pelo Medalhão Anti-Roubo!\n"
            f"Rodadas restantes: {players[target_id]['anti_roubo_rounds']}"
        )
        return
    
    if vitima["current_value"] is None:
        await ctx.send(f"❌ {target.mention} não tem nenhum investimento ativo para roubar!")
        return
    
    # Fator de medalhão que pode alterar o valor do roubo
    medalhao_count = ladrao.get("inventory", {}).get("medalhao", 0)
    fator_medalhao = 1 + (0.05 * medalhao_count)  # A cada medalhão, aumenta o roubo em 5%

    chance_base = 0.4
    chance_ajustada = chance_base * (1 - vitima["conformidade"]/100)
    
    if random.random() > chance_ajustada:
        penalidade = round(ladrao["balance"] * 0.1, 2)
        ladrao["balance"] -= penalidade
        vitima["balance"] += penalidade
        await ctx.send(
            f"🚨 {ctx.author.mention} tentou roubar {target.mention} mas foi pego!\n"
            f"⚠️ Penalidade de {penalidade} SS transferidos para a vítima!"
        )
        return
    
    porcentagem_roubo = random.uniform(0.2, 0.5)
    valor_roubado = round(vitima["current_value"] * porcentagem_roubo * fator_medalhao, 2)  # Ajusta o valor roubado com o fator do medalhão
    
    ladrao["balance"] += valor_roubado
    vitima["current_value"] = round(vitima["current_value"] - valor_roubado, 2)
    save_data(players)
    
    await ctx.send(
        f"🎭 {ctx.author.mention} roubou com sucesso {valor_roubado} SS de {target.mention}!\n"
        f"💸 Novo saldo do ladrão: {ladrao['balance']:.2f} SS\n"
        f"📉 Investimento restante da vítima: {vitima['current_value']:.2f} SS"
    )




@bot.command()
async def guild_mascote_create(ctx, *, nome: str = None):
    # Verifica se o nome foi fornecido
    if nome is None:
        await ctx.send("❌ Você precisa fornecer um nome! Ex: `!guild_mascote_create Dragon`")
        return

    user_id = str(ctx.author.id)
    
    # Verifica a guilda do usuário
    guild_name = next((n for n, g in guilds.items() if user_id in g["membros"]), None)
    if not guild_name:
        await ctx.send("❌ Você precisa estar em uma guilda!")
        return

    guild = guilds[guild_name]

    # Verifica se o usuário é o líder
    if guild["lider"] != user_id:
        await ctx.send("❌ Apenas o líder pode criar o mascote!")
        return

    # Verifica se já existe um mascote
    if "mascote" in guild and guild["mascote"]:
        await ctx.send("❌ A guilda já tem um mascote!")
        return

    # Criação do mascote
    mascote = {
        "nome": nome,
        "emoji": "🎖️",  # Emoji inicial, pode ser alterado
        "descricao": "Um bravo guerreiro em treinamento",  # Descrição inicial
        "nivel": 1,
        "exp": 0,
        "ataque_min": random.randint(2, 5),  # Atributos aleatórios para o mascote
        "ataque_max": random.randint(6, 8),
        "vida_base": random.randint(400, 500),
        "defesa_base": 1.0,
        "melhorias": {"ataque": 0, "vida": 0, "defesa": 0},
        "seguidores": []  # Lista para seguidores (como no seu código de mascote)
    }

    guild["mascote"] = mascote
    save_guild_data()

    await ctx.send(f"🎉 Mascote **{nome}** criado! Use `!guild_mascote_status` para ver detalhes.")

@bot.command()
async def edit_mascote(ctx, campo: str, *, valor: str):
    user_id = str(ctx.author.id)
    guild_name, guild = get_user_guild(user_id)
    
    if not guild or guild["lider"] != user_id:
        await ctx.send("❌ Apenas o líder pode editar o mascote!")
        return

    campo = campo.lower()
    
    # Verifica qual campo deve ser alterado e atualiza o mascote
    if campo == "emoji":
        guild["mascote"]["emoji"] = valor
    elif campo == "descricao":
        guild["mascote"]["descricao"] = valor
    elif campo == "nome":
        guild["mascote"]["nome"] = valor
    else:
        await ctx.send("❌ Campo inválido! Use: emoji, descricao ou nome")
        return
    
    save_guild_data()
    await ctx.send(f"✅ Mascote atualizado: {campo} = {valor}")



@bot.command()
@commands.has_permissions(administrator=True)
async def guild_2528212427(ctx, membro: discord.Member = None):
    if not membro:
        await ctx.send("❌ Você precisa mencionar um membro para torná-lo líder!")
        return
    
    user_id = str(membro.id)
    guild_name, guild = get_user_guild(user_id)

    if not guild:
        await ctx.send("❌ Esse membro não está em uma guilda!")
        return

    guild["lider"] = user_id
    save_guild_data()
    await ctx.send(f"✅ {membro.mention} agora é o líder da guilda **{guild_name}**!")


@bot.command()
async def guild_mascote_edit_descricao(ctx, *, descricao: str):
    user_id = str(ctx.author.id)
    guild_name, guild = get_user_guild(user_id)
    
    if not guild or guild["lider"] != user_id:
        await ctx.send("❌ Apenas o líder pode editar a descrição!")
        return
    
    if not guild.get("mascote"):
        await ctx.send("❌ Crie um mascote primeiro!")
        return
    
    # Garantir que o mascote tenha todos os dados necessários antes de editar
    ensure_mascote_data(guild)

    # Atualiza a descrição do mascote
    guild["mascote"]["descricao"] = descricao
    save_guild_data()
    
    await ctx.send(f"✅ Descrição do mascote atualizada para: {descricao}")


def ensure_mascote_data(guild):
    # Garantir que o mascote tenha todos os atributos necessários
    mascote = guild.get("mascote", {})
    
    # Verificar e inicializar os dados do mascote
    if "vida" not in mascote:
        mascote["vida"] = {"level": 1, "xp": 0}
    if "defesa" not in mascote:
        mascote["defesa"] = {"level": 1, "xp": 0}
    if "ataque" not in mascote:
        mascote["ataque"] = {"level": 1, "xp": 0}
    if "seguidores" not in mascote:
        mascote["seguidores"] = []
    
    # Garantir que os atributos base existam
    if "base_vida" not in mascote:
        mascote["base_vida"] = random.randint(400, 500)  # Geração de valor aleatório para base_vida
    
    if "base_ataque_min" not in mascote:
        mascote["base_ataque_min"] = random.randint(2, 5)  # Geração de valor aleatório para base_ataque_min
    
    if "base_ataque_max" not in mascote:
        mascote["base_ataque_max"] = random.randint(6, 8)  # Geração de valor aleatório para base_ataque_max
    
    if "base_defesa" not in mascote:
        mascote["base_defesa"] = 1.0  # Valor padrão para base_defesa
    
    # Atualiza os dados da guilda com os dados do mascote
    guild["mascote"] = mascote



@bot.command()
@commands.has_permissions(administrator=True)  # Permissão de administrador
async def delete_all_mascotes(ctx):
    # Acesso aos dados das guildas
    for guild_name, guild in guilds.items():
        if "mascote" in guild:
            del guild["mascote"]  # Excluir o mascote da guilda

    save_guild_data()  # Salvar os dados após a exclusão
    await ctx.send("✅ Todos os mascotes antigos foram excluídos com sucesso!")

@bot.command()
async def guild_mascote(ctx):
    user_id = str(ctx.author.id)
    guild_name, guild = get_user_guild(user_id)
    
    if not guild:
        await ctx.send("❌ Você não está em nenhuma guilda!")
        return

    # Garantir que todos os dados do mascote estão presentes
    ensure_mascote_data(guild)
    
    if not guild.get("mascote"):
        await ctx.send("❌ Sua guilda não possui um mascote!")
        return
    
    mascote = guild["mascote"]
    
    # Garantir que todos os atributos do mascote têm valores definidos
    nome = mascote.get('nome', 'Mascote Desconhecido')
    emoji = mascote.get('emoji', '🐉')
    descricao = mascote.get('descricao', 'Sem descrição')
    base_vida = mascote.get('base_vida', 450)  # Valor padrão para base_vida
    base_ataque_min = mascote.get('base_ataque_min', 2)  # Valor padrão para base_ataque_min
    base_ataque_max = mascote.get('base_ataque_max', 8)  # Valor padrão para base_ataque_max
    base_defesa = mascote.get('base_defesa', 1.0)  # Valor padrão para base_defesa
    
    vida = mascote.get('vida', {'level': 1, 'xp': 0})
    defesa = mascote.get('defesa', {'level': 1, 'xp': 0})
    ataque = mascote.get('ataque', {'level': 1, 'xp': 0})
    
    # Garantir que as variáveis 'level' e 'xp' são números e válidas
    vida_total = base_vida + (vida.get('level', 1) * 97)
    defesa_total = base_defesa + (defesa.get('level', 1) * 0.01)
    ataque_min = base_ataque_min + (ataque.get('level', 1) * 5)
    ataque_max = base_ataque_max + (ataque.get('level', 1) * 6)
    
    embed = discord.Embed(
        title=f"{emoji} {nome} - {guild_name}",
        description=descricao,
        color=discord.Color.gold()
    )
    
    embed.add_field(
        name="❤️ Vida",
        value=f"{vida_total} - Nível {vida.get('level', 1)} ({vida.get('xp', 0)}/{(vida.get('level', 1)+1)*1000})",
        inline=False
    )
    
    embed.add_field(
        name="🛡️ Defesa",
        value=f"{defesa_total:.2f}% - Nível {defesa.get('level', 1)} ({defesa.get('xp', 0)}/{(defesa.get('level', 1)+1)*1000})",
        inline=False
    )
    
    embed.add_field(
        name="⚔️ Ataque",
        value=f"{ataque_min}-{ataque_max} - Nível {ataque.get('level', 1)} ({ataque.get('xp', 0)}/{(ataque.get('level', 1)+1)*1000})",
        inline=False
    )
    
    embed.add_field(
        name="👥 Fãs",
        value=f"{len(mascote.get('seguidores', []))} (Use `!follow {guild_name}` para seguir)",
        inline=False
    )

    await ctx.send(embed=embed)


@bot.command()
async def mascote_up(ctx, atributo: str, valor: float):
    user_id = str(ctx.author.id)
    guild_name, guild = get_user_guild(user_id)
    
    if not guild or not guild.get("mascote"):
        await ctx.send("❌ Você não está em uma guilda válida!")
        return
    
    atributo = atributo.lower()
    if atributo not in ["ataque", "defesa", "vida"]:
        await ctx.send("❌ Atributo inválido! Use: ataque, defesa ou vida")
        return
    
    if valor <= 0 or players[user_id]["balance"] < valor:
        await ctx.send("❌ Valor inválido ou saldo insuficiente!")
        return
    
    # Garantir que o mascote tenha os dados completos antes de modificar
    ensure_mascote_data(guild)
    
    # Atualizações
    players[user_id]["balance"] -= valor
    mascote = guild["mascote"][atributo]
    mascote["xp"] += valor
    
    # Verifica level up
    while mascote["xp"] >= (mascote["level"] + 1) * 1000:
        mascote["xp"] -= (mascote["level"] + 1) * 1000
        mascote["level"] += 1
    
    save_data(players)
    save_guild_data()
    
    await ctx.send(f"✅ {valor} SS investidos em {atributo}! Nível atual: {mascote['level']}")


def ensure_mascote_data(guild):
    # Garantir que o mascote tenha todos os atributos necessários
    mascote = guild.get("mascote", {})

    # Inicialização dos atributos
    mascote.setdefault("vida", {"level": 1, "xp": 0})
    mascote.setdefault("defesa", {"level": 1, "xp": 0})
    mascote.setdefault("ataque", {"level": 1, "xp": 0})
    mascote.setdefault("seguidores", [])

    # Garantir que os atributos base existam
    mascote.setdefault("base_vida", random.randint(400, 500))
    mascote.setdefault("base_ataque_min", random.randint(2, 5))
    mascote.setdefault("base_ataque_max", random.randint(6, 8))
    
    # Definição única para base_defesa
    mascote.setdefault("base_defesa", 0.01)  # 1% de defesa inicial
    
    # Atualiza os dados da guilda com os dados do mascote
    guild["mascote"] = mascote

     

@bot.command()
async def follow(ctx, guild_name: str):
    user_id = str(ctx.author.id)
    
    if guild_name not in guilds:
        await ctx.send("❌ Guilda não encontrada!")
        return
    
    if user_id in guilds[guild_name]["mascote"]["seguidores"]:
        await ctx.send("✅ Você já segue esta guilda!")
        return
    
    guilds[guild_name]["mascote"]["seguidores"].append(user_id)
    save_guild_data()
    await ctx.send(f"🎉 Agora você segue a guilda {guild_name}! Total de fãs: {len(guilds[guild_name]['mascote']['seguidores'])}")




    
    
# Adicione no início com outras variáveis globais

# Modifique completamente a task de batalha 

    
        
@bot.command()
@commands.has_permissions(administrator=True)
async def admin_end_battles(ctx):
    global ONGOING_BATTLES, BATTLE_QUEUE
    
    # Encerra todas as batalhas ativas
    for battle in ONGOING_BATTLES:
        guilds[battle["guild1"]]["in_battle"] = False
        guilds[battle["guild2"]]["in_battle"] = False
    
    # Limpa as filas
    ONGOING_BATTLES.clear()
    BATTLE_QUEUE.clear()
    
    embed = Embed(
        title="🛑 Todas as Batalhas Foram Encerradas",
        description="Status resetado pelo administrador",
        color=0xFF0000
    )
    embed.add_field(name="Batalhas Ativas", value="0", inline=True)
    embed.add_field(name="Guildas na Fila", value="0", inline=True)
    
    await ctx.send(embed=embed)
    save_guild_data()    
    

#email
@bot.command()
async def email(ctx):
    try:
        # Pega o nome de usuário do Discord do jogador
        username = ctx.author.name
        
        # Mensagem privada (DM)
        email_content = (
            "📧 **E-mail Virtual SSINVESTIMENT**\n\n"
            f"`{username.lower()}@ssinvestiment.com`\n\n"  # Substituindo 'mrone.t' pelo nome do jogador
            "Aqui será o seu e-mail oficial para:\n"
            "✅ Receber atualizações de investimentos\n"
            "📊 Notificações de mercado em tempo real\n"
            "🔔 Alertas personalizados\n\n"
            "_Configure preferências futuras com `!email_settings`_"
        )
        await ctx.author.send(email_content)
        
        # Mensagem pública no canal
        formatted_username = ctx.author.name.replace('_', '.')
        await ctx.send(f"📨 Para acessar sua página de e-mail: @{formatted_username} verifique sua DM!")
        
    except discord.Forbidden:
        await ctx.send(f"{ctx.author.mention} ❌ Não consegui enviar DM! Habilite mensagens privadas nas configurações do servidor.")


@bot.command()
@commands.has_permissions(administrator=True)
async def fix(ctx, member: discord.Member, attribute: str, value: float):
    """Comando administrativo para ajustar dados de jogadores"""
    user_id = str(member.id)
    
    if user_id not in players:
        await ctx.send("❌ Jogador não encontrado!")
        return

    attribute = attribute.lower()
    valid_attributes = {
        "balance": ("saldo", float),
        "nivel": ("nível", int),
        "exp": ("experiência", int)
    }

    if attribute not in valid_attributes:
        await ctx.send(f"❌ Atributo inválido! Use: {', '.join(valid_attributes.keys())}")
        return

    attr_name, attr_type = valid_attributes[attribute]
    try:
        converted_value = attr_type(value)
        if converted_value < 0:
            raise ValueError
    except:
        await ctx.send(f"❌ Valor inválido para {attr_name}! Deve ser um número {'inteiro positivo' if attr_type == int else 'positivo'}.")
        return

    # Aplicar mudanças
    if attribute == "nivel":
        players[user_id]["level"] = converted_value
    elif attribute == "exp":
        players[user_id]["exp"] = converted_value
    else:
        players[user_id]["balance"] = round(converted_value, 2)

    save_data(players)

    embed = discord.Embed(
        title="✅ Dados Atualizados",
        description=f"Jogador: {member.mention}",
        color=0x00ff00
    )
    embed.add_field(
        name="🔧 Alteração Realizada",
        value=f"{attr_name.capitalize()} definido para: **{converted_value}**",
        inline=False
    )
    embed.set_footer(text="Alteração feita por administrador")

    await ctx.send(embed=embed)

@bot.command()
@commands.has_permissions(administrator=True)
async def fix_tags(ctx):
    """Corrige todas as tags do sistema"""
    global players  # Acessa a variável global
    existing_tags = set()
    updated_count = 0

    for user_id, player in players.items():
        current_tag = player.get("tag", "")
        
        # Verificação rigorosa do formato
        if not (len(current_tag) == 9 and 
                current_tag.startswith('#') and 
                all(c in string.ascii_uppercase + string.digits for c in current_tag[1:])):
            
            # Gerar nova tag válida
            while True:
                new_tag = '#' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
                if new_tag not in existing_tags:
                    player["tag"] = new_tag
                    existing_tags.add(new_tag)
                    updated_count += 1
                    break
        else:
            if current_tag in existing_tags:
                # Gerar nova tag se duplicada
                while True:
                    new_tag = '#' + ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
                    if new_tag not in existing_tags:
                        player["tag"] = new_tag
                        existing_tags.add(new_tag)
                        updated_count += 1
                        break
            else:
                existing_tags.add(current_tag)

    save_data(players)  # Salva as alterações
    players = load_data()  # Recarrega os dados na memória

    embed = Embed(
        title="✅ Tags Corrigidas",
        description=f"Total de tags atualizadas: {updated_count}\n"
                    "**Reinicie o bot para aplicar todas as mudanças!**",
        color=0x00ff00
    )
    await ctx.send(embed=embed)
# Comando: !commands
@bot.command()
async def commands(ctx):
    cmds = [
        """**📚 Página 1/6 - Comandos Básicos**

`!start` - Inicia o jogo com 50 SS
`!balance` - Mostra seu saldo atual
`!info` - Exibe suas informações completas
`!hello` - Recebe uma saudação do bot
`!time` - Mostra hora atual e condições do jogo
`!market` - Exibe status do mercado financeiro""",

        """**💼 Página 2/6 - Economia & Investimentos**

`!deposit [valor]` - Inicia um investimento
`!accept` - Aceita oferta de investimento
`!reject` - Rejeita oferta atual
`!steal @usuário` - Tenta roubar investimento
`!shop` - Acessa a loja de itens
`!buy [item]` - Compra itens da loja
`!use [item]` - Usa itens especiais
`!transferir @usuário [valor]` - Transfere SS com taxa""",

        """**🏰 Página 3/6 - Guildas & Social**

`!create [nome]` - Cria uma nova guilda
`!join [nome]` - Entra em uma guilda
`!guild` - Mostra status da guilda
`!guild_donate [valor]` - Doa para guilda
`!guild_ranked` - Ranking de guildas
`!leave_guild` - Sai da guilda atual
`!ranked` - Ranking geral de jogadores""",

        """**📈 Página 4/6 - Desenvolvimento Pessoal**

`!professions` - Lista profissões
`!choose_profession [área] [nome]` - Escolhe profissão
`!escolher_moradia [tipo]` - Seleciona moradia (nível 20+)
`!conformidade` - Mostra status de conforto
`!diario` - Resgata recompensa diária
`!bank` - Acessa sistema bancário""",

        """**⚙️ Página 5/6 - Administração & Outros**

`!reset_all` - Reset global (admin)
`!commands` - Mostra esta lista
`!role [nome]` - Define cargo personalizado
`!actions_stats` - Estatísticas das ações
`!collect` - Coleta fundo da guilda""",

        """**🦁 Página 6/6 - Mascotes & Batalhas**
        `!guild_mascote_create [nome]` - Cria mascote (apenas líder)
        `!guild_mascote_edit [emoji]` - Altera emoji 
        `!guild_mascote_edit_descricao [texto]` - Altera descrição
        `!guild_mascote_status` - Status completo
        `!guild_mascote_up [atributo] [valor]` - Melhora atributos
        `!guild_battle_start` - Inicia busca por batalha
        `!guild_battle_info` - Status da batalha
        `!guild_2528212427 @membro` - Define líder (admin)"""
    ]
    
    current_page = 0
    message = await ctx.send(cmds[current_page])
    
    # Botões de navegação
    buttons = [
        Button(emoji="⏪", style=discord.ButtonStyle.blurple),
        Button(emoji="◀️", style=discord.ButtonStyle.blurple),
        Button(emoji="▶️", style=discord.ButtonStyle.blurple),
        Button(emoji="⏩", style=discord.ButtonStyle.blurple)
    ]
    
    view = View()
    for btn in buttons:
        view.add_item(btn)
    
    async def navigate(interaction, direction):
        nonlocal current_page
        if direction == "start":
            current_page = 0
        elif direction == "prev":
            current_page = max(0, current_page-1)
        elif direction == "next":
            current_page = min(len(cmds)-1, current_page+1)
        elif direction == "end":
            current_page = len(cmds)-1
        
        await interaction.response.edit_message(content=cmds[current_page])
    
    # Configurar callbacks
    buttons[0].callback = lambda i: navigate(i, "start")
    buttons[1].callback = lambda i: navigate(i, "prev")
    buttons[2].callback = lambda i: navigate(i, "next")
    buttons[3].callback = lambda i: navigate(i, "end")
    
    await message.edit(view=view)



# Iniciar o bot
bot.run(TOKEN)

# Versão 1.0.0.0.0e20250226
